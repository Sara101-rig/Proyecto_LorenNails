/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Servicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServicioDAO {

    private final Conexion conect = new Conexion();

    public boolean insertarServicio(Servicio miServicio) {

        boolean insertar = false;

        String querySql = "INSERT INTO servicio "
                + "(nombre, descripcion, precio, catalogo_id_catalogo) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miServicio.getNombre());
            ps.setString(2, miServicio.getDescripcion());
            ps.setBigDecimal(3, miServicio.getPrecio());
            ps.setInt(4, miServicio.getCatalogoidCatalogo());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                insertar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar servicio: "
                    + e.getMessage());
        }

        return insertar;
    }

    public Servicio consultarServicio(int idServicio) {

        Servicio miServicio = null;

        String querySql = "SELECT id_servicios, nombre, descripcion, "
                + "precio, catalogo_id_catalogo "
                + "FROM servicio WHERE id_servicios = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idServicio);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    miServicio = new Servicio();

                    miServicio.setIdServicio(
                            rs.getInt("id_servicios")
                    );

                    miServicio.setNombre(
                            rs.getString("nombre")
                    );

                    miServicio.setDescripcion(
                            rs.getString("descripcion")
                    );

                    miServicio.setPrecio(
                            rs.getBigDecimal("precio")
                    );

                    miServicio.setCatalogoidCatalogo(
                            rs.getInt("catalogo_id_catalogo")
                    );
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar servicio: "
                    + e.getMessage());
        }

        return miServicio;
    }

    public boolean actualizarServicio(Servicio miServicio) {

        boolean actualizar = false;

        String querySql = "UPDATE servicio SET nombre = ?, "
                + "descripcion = ?, precio = ?, "
                + "catalogo_id_catalogo = ? "
                + "WHERE id_servicios = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miServicio.getNombre());
            ps.setString(2, miServicio.getDescripcion());
            ps.setBigDecimal(3, miServicio.getPrecio());
            ps.setInt(4, miServicio.getCatalogoidCatalogo());
            ps.setInt(5, miServicio.getIdServicio());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar servicio: "
                    + e.getMessage());
        }

        return actualizar;
    }

    public boolean eliminarServicio(Servicio miServicio) {

        boolean eliminar = false;

        String querySql = "DELETE FROM servicio "
                + "WHERE id_servicios = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miServicio.getIdServicio());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar servicio: "
                    + e.getMessage());
        }

        return eliminar;
    }
}
