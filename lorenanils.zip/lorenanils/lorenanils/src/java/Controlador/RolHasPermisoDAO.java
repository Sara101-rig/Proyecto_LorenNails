/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.RolHasPermiso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RolHasPermisoDAO {

    private final Conexion conect = new Conexion();

    // 1. CONSULTAR RELACIÓN ROL - PERMISO
    public RolHasPermiso consultarRolHasPermiso(int idRol, int idPermiso) {
        RolHasPermiso miRolHasPermiso = null;

        // CORREGIDO: Usando el nombre exacto de la tabla con guiones bajos
        String querySql = "SELECT rol_id_rol, permiso_id_permiso "
                + "FROM rol_has_permiso "
                + "WHERE rol_id_rol = ? AND permiso_id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);
            ps.setInt(2, idPermiso);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRolHasPermiso = new RolHasPermiso();
                    miRolHasPermiso.setRolIdRol(rs.getInt("rol_id_rol"));
                    miRolHasPermiso.setPermisoIdPermiso(rs.getInt("permiso_id_permiso"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al consultar el permiso del rol: " + e.getMessage());
        }

        return miRolHasPermiso;
    }

    // 2. INSERTAR / ASIGNAR PERMISO A UN ROL
    public boolean insertarRolHasPermiso(RolHasPermiso miRolHasPermiso) {
        boolean insertar = false;

        String querySql = "INSERT INTO rol_has_permiso (rol_id_rol, permiso_id_permiso) VALUES (?, ?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRolHasPermiso.getRolIdRol());
            ps.setInt(2, miRolHasPermiso.getPermisoIdPermiso());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Permiso asignado al rol");

        } catch (SQLException e) {
            System.out.println("Error al asignar el permiso al rol: " + e.getMessage());
        }

        return insertar;
    }

    // 3. ACTUALIZAR RELACIÓN
    public boolean actualizarRolHasPermiso(
            RolHasPermiso miRolHasPermiso,
            int idRolAnterior,
            int idPermisoAnterior) {

        boolean actualizar = false;

        String querySql = "UPDATE rol_has_permiso SET "
                + "rol_id_rol = ?, permiso_id_permiso = ? "
                + "WHERE rol_id_rol = ? "
                + "AND permiso_id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRolHasPermiso.getRolIdRol());
            ps.setInt(2, miRolHasPermiso.getPermisoIdPermiso());
            ps.setInt(3, idRolAnterior);
            ps.setInt(4, idPermisoAnterior);

            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el permiso del rol: " + e.getMessage());
        }

        return actualizar;
    }

    // 4. ELIMINAR RELACIÓN
    public boolean eliminarRolHasPermiso(RolHasPermiso miRolHasPermiso) {
        boolean eliminar = false;

        String querySql = "DELETE FROM rol_has_permiso "
                + "WHERE rol_id_rol = ? "
                + "AND permiso_id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRolHasPermiso.getRolIdRol());
            ps.setInt(2, miRolHasPermiso.getPermisoIdPermiso());

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el permiso del rol: " + e.getMessage());
        }

        return eliminar;
    }

    // 5. ACTIVAR RELACIÓN
    public boolean activarRolHasPermiso(RolHasPermiso miRolHasPermiso) {
        boolean activar = false;
        RolHasPermiso existe = consultarRolHasPermiso(miRolHasPermiso.getRolIdRol(), miRolHasPermiso.getPermisoIdPermiso());
        
        if (existe != null) {
            activar = true;
            System.out.println("La relación rol-permiso ya se encuentra activa.");
        } else {
            System.out.println("No se encontró la relación en la base de datos.");
        }
        return activar;
    }

    // 6. INACTIVAR RELACIÓN
    public boolean inactivarRolHasPermiso(RolHasPermiso miRolHasPermiso) {
        boolean inactivar = false;
        inactivar = eliminarRolHasPermiso(miRolHasPermiso);
        
        if (inactivar) {
            System.out.println("Relación inactivada (permiso removido del rol).");
        }
        
        return inactivar;
    }
}