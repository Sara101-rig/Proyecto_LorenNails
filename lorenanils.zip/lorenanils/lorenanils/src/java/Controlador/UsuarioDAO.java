package Controlador;

import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    private final Conexion conect = new Conexion();

    public Usuario consultarUsuario(int idUsuario) {
        Usuario miUsuario = null;
        // CORREGIDIO: id_rol cambiado por rol_id_rol
        String querySql = "SELECT id_usuario, nombre, apellido, "
                + "numero_identidad, fecha_nacimiento, correo, telefono, "
                + "direccion, estado, tipo_documento_id_tipo_documento, rol_id_rol "
                + "FROM usuario WHERE id_usuario = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miUsuario = new Usuario();
                    miUsuario.setIdUsuario(rs.getInt("id_usuario"));
                    miUsuario.setNombre(rs.getString("nombre"));
                    miUsuario.setApellido(rs.getString("apellido"));
                    miUsuario.setNumeroIdentidad(rs.getString("numero_identidad"));
                    miUsuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                    miUsuario.setCorreo(rs.getString("correo"));
                    miUsuario.setTelefono(rs.getString("telefono"));
                    miUsuario.setDireccion(rs.getString("direccion"));
                    miUsuario.setEstado(rs.getInt("estado"));
                    miUsuario.setTipoDocumentoIdTipoDocumento(
                            rs.getInt("tipo_documento_id_tipo_documento"));
                    miUsuario.setIdRol(rs.getInt("rol_id_rol"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar usuario: " + e.getMessage());
        }

        return miUsuario;
    }

    public boolean insertarUsuario(Usuario miUsuario) {
    boolean insertar = false;

    String querySql = "INSERT INTO usuario "
            + "(nombre, apellido, numero_identidad, fecha_nacimiento, "
            + "correo, telefono, direccion, estado, "
            + "tipo_documento_id_tipo_documento, rol_id_rol, contrasena) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = conect.getConn();
            PreparedStatement ps = conn.prepareStatement(querySql)) {

        ps.setString(1, miUsuario.getNombre());
        ps.setString(2, miUsuario.getApellido());
        ps.setString(3, miUsuario.getNumeroIdentidad());
        ps.setDate(4, miUsuario.getFechaNacimiento());
        ps.setString(5, miUsuario.getCorreo());
        ps.setString(6, miUsuario.getTelefono());
        ps.setString(7, miUsuario.getDireccion());
        ps.setInt(8, miUsuario.getEstado());
        ps.setInt(9, miUsuario.getTipoDocumentoIdTipoDocumento());
        ps.setInt(10, miUsuario.getIdRol());
        
        // ¡Línea que faltaba! Asignar la contraseña al parámetro 11
        ps.setString(11, miUsuario.getContrasena());

        int filas = ps.executeUpdate();

        if (filas > 0) {
            insertar = true;
        }

    } catch (SQLException e) {
        System.out.println("Error al insertar usuario: " + e.getMessage());
        throw new RuntimeException("Error exacto de MySQL: " + e.getMessage());
    }

    return insertar;
}

    public boolean actualizarUsuario(Usuario miUsuario) {
        boolean actualizar = false;
        
        String querySql = "UPDATE usuario SET nombre = ?, apellido = ?, "
                + "numero_identidad = ?, fecha_nacimiento = ?, correo = ?, "
                + "telefono = ?, direccion = ?, estado = ?, "
                + "tipo_documento_id_tipo_documento = ?, rol_id_rol = ? "
                + "WHERE id_usuario = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miUsuario.getNombre());
            ps.setString(2, miUsuario.getApellido());
            ps.setString(3, miUsuario.getNumeroIdentidad());
            ps.setDate(4, miUsuario.getFechaNacimiento());
            ps.setString(5, miUsuario.getCorreo());
            ps.setString(6, miUsuario.getTelefono());
            ps.setString(7, miUsuario.getDireccion());
            ps.setInt(8, miUsuario.getEstado());
            ps.setInt(9, miUsuario.getTipoDocumentoIdTipoDocumento());
            ps.setInt(10, miUsuario.getIdRol());
            ps.setInt(11, miUsuario.getIdUsuario());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar usuario: " + e.getMessage());
        }

        return actualizar;
    }

    public boolean eliminarUsuario(Usuario miUsuario) {
        boolean eliminar = false;
        String querySql = "DELETE FROM usuario WHERE id_usuario = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miUsuario.getIdUsuario());
            int filas = ps.executeUpdate();

            if (filas > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
        }

        return eliminar;
    }

    public boolean activarUsuario(Usuario miUsuario) {
        boolean activar = false;
        String querySql = "UPDATE usuario SET estado = 1 WHERE id_usuario = ?"; // Ajustado a valor numérico TINYINT

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miUsuario.getIdUsuario());
            int filas = ps.executeUpdate();

            if (filas > 0) {
                activar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al activar usuario: " + e.getMessage());
        }

        return activar;
    }

    public boolean inactivarUsuario(Usuario miUsuario) {
        boolean inactivar = false;
        String querySql = "UPDATE usuario SET estado = 0 WHERE id_usuario = ?"; // Ajustado a valor numérico TINYINT

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miUsuario.getIdUsuario());
            int filas = ps.executeUpdate();

            if (filas > 0) {
                inactivar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al inactivar usuario: " + e.getMessage());
        }

        return inactivar;
    }

    public Usuario consultarUsuarioPorCorreo(String correo) {
        Usuario miUsuario = null;
        
        String querySql = "SELECT id_usuario, nombre, apellido, numero_identidad, "
                + "fecha_nacimiento, correo, telefono, direccion, estado, "
                + "tipo_documento_id_tipo_documento, rol_id_rol, contrasena "
                + "FROM usuario WHERE correo = ?";

        try (Connection conn = conect.getConn();
               PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, correo);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miUsuario = new Usuario();
                    miUsuario.setIdUsuario(rs.getInt("id_usuario"));
                    miUsuario.setNombre(rs.getString("nombre"));
                    miUsuario.setApellido(rs.getString("apellido"));
                    miUsuario.setNumeroIdentidad(rs.getString("numero_identidad"));
                    miUsuario.setFechaNacimiento(rs.getDate("fecha_nacimiento"));
                    miUsuario.setCorreo(rs.getString("correo"));
                    miUsuario.setTelefono(rs.getString("telefono"));
                    miUsuario.setDireccion(rs.getString("direccion"));
                    miUsuario.setEstado(rs.getInt("estado"));
                    miUsuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_id_tipo_documento"));
                    miUsuario.setIdRol(rs.getInt("rol_id_rol"));
                    miUsuario.setContrasena(rs.getString("contrasena"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar usuario por correo: " + e.getMessage());
        }

        return miUsuario;
    }

    public boolean validarLogin(String correo, String contrasena) {
        boolean esValido = false;
        Usuario usuario = consultarUsuarioPorCorreo(correo);
        
        if (usuario != null) {
            if (usuario.getContrasena() != null && usuario.getContrasena().equals(contrasena)) {
                esValido = true;
            }
        }
        
        return esValido;
    }

   public Usuario obtenerUsuarioPorCorreo(String correo) {
        return this.consultarUsuarioPorCorreo(correo);
    }
}