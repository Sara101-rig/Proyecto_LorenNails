/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CategoriaDAO {

    private final Conexion conect = new Conexion();

    public Categoria consultarCategoria(int idCategoria) {

        Categoria miCategoria = null;

        String querySql = "SELECT id_categoria, descripcion "
                + "FROM categoria WHERE id_categoria = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idCategoria);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    miCategoria = new Categoria();

                    miCategoria.setIdCategoria(
                            rs.getInt("id_categoria"));

                    miCategoria.setDescripcion(
                            rs.getString("descripcion"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar categoría: " + e.getMessage());
        }

        return miCategoria;
    }

    public boolean insertarCategoria(Categoria miCategoria) {

        boolean insertar = false;

        String querySql = "INSERT INTO categoria (descripcion) VALUES (?)";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miCategoria.getDescripcion());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                insertar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar categoría: " + e.getMessage());
        }

        return insertar;
    }

    public boolean actualizarCategoria(Categoria miCategoria) {

        boolean actualizar = false;

        String querySql = "UPDATE categoria SET descripcion = ? "
                + "WHERE id_categoria = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miCategoria.getDescripcion());
            ps.setInt(2, miCategoria.getIdCategoria());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar categoría: " + e.getMessage());
        }

        return actualizar;
    }

    public boolean eliminarCategoria(Categoria miCategoria) {

        boolean eliminar = false;

        String querySql = "DELETE FROM categoria WHERE id_categoria = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miCategoria.getIdCategoria());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar categoría: " + e.getMessage());
        }

        return eliminar;
    }
}
