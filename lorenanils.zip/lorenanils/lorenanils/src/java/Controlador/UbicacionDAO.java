/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Ubicacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UbicacionDAO {

    private final Conexion conect = new Conexion();

    public Ubicacion consultarUbicacion(int idUbicacion) {

        Ubicacion miUbicacion = null;

        String querySql = "SELECT id_ubicacion, direccion, referencia, "
                + "usuario_id_usuario FROM ubicacion "
                + "WHERE id_ubicacion = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idUbicacion);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    miUbicacion = new Ubicacion();

                    miUbicacion.setIdUbicacion(rs.getInt("id_ubicacion"));
                    miUbicacion.setDireccion(rs.getString("direccion"));
                    miUbicacion.setReferencia(rs.getString("referencia"));
                    miUbicacion.setUsuarioIdUsuario(
                            rs.getInt("usuario_id_usuario"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar ubicación: " + e.getMessage());
        }

        return miUbicacion;
    }

    public boolean insertarUbicacion(Ubicacion miUbicacion) {

        boolean insertar = false;

        String querySql = "INSERT INTO ubicacion "
                + "(direccion, referencia, usuario_id_usuario) "
                + "VALUES (?, ?, ?)";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miUbicacion.getDireccion());
            ps.setString(2, miUbicacion.getReferencia());
            ps.setInt(3, miUbicacion.getUsuarioIdUsuario());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                insertar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar ubicación: " + e.getMessage());
        }

        return insertar;
    }

    public boolean actualizarUbicacion(Ubicacion miUbicacion) {

        boolean actualizar = false;

        String querySql = "UPDATE ubicacion SET direccion = ?, "
                + "referencia = ?, usuario_id_usuario = ? "
                + "WHERE id_ubicacion = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miUbicacion.getDireccion());
            ps.setString(2, miUbicacion.getReferencia());
            ps.setInt(3, miUbicacion.getUsuarioIdUsuario());
            ps.setInt(4, miUbicacion.getIdUbicacion());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar ubicación: " + e.getMessage());
        }

        return actualizar;
    }

    public boolean eliminarUbicacion(Ubicacion miUbicacion) {

        boolean eliminar = false;

        String querySql = "DELETE FROM ubicacion WHERE id_ubicacion = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miUbicacion.getIdUbicacion());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar ubicación: " + e.getMessage());
        }

        return eliminar;
    }
}
