/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RolDAO {

    private final Conexion conect = new Conexion();

    // 1. CONSULTAR ROL POR ID
    public Rol consultarRol(int idRol) {
        Rol miRol = null;

        String querySql = "SELECT id_rol, nombre, descripcion "
                + "FROM Rol WHERE id_rol = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idRol);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRol = new Rol();
                    miRol.setIdRol(rs.getInt("id_rol"));
                    miRol.setNombre(rs.getString("nombre"));
                    miRol.setDescripcion(rs.getString("descripcion"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al consultar el rol: " + e.getMessage());
        }

        return miRol;
    }

    // 2. INSERTAR ROL
    public boolean insertarRol(Rol miRol) {
        boolean insertar = false;

        String querySql = "INSERT INTO Rol(nombre, descripcion) VALUES (?, ?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miRol.getNombre());
            ps.setString(2, miRol.getDescripcion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Rol insertado");

        } catch (SQLException e) {
            System.out.println("Error al insertar el rol: " + e.getMessage());
        }

        return insertar;
    }

    // 3. ACTUALIZAR ROL
    public boolean actualizarRol(Rol miRol) {
        boolean actualizar = false;

        String querySql = "UPDATE Rol SET nombre = ?, descripcion = ? WHERE id_rol = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miRol.getNombre());
            ps.setString(2, miRol.getDescripcion());
            ps.setInt(3, miRol.getIdRol());

            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el rol: " + e.getMessage());
        }

        return actualizar;
    }

    // 4. ELIMINAR ROL
    public boolean eliminarRol(Rol miRol) {
        boolean eliminar = false;

        String querySql = "DELETE FROM Rol WHERE id_rol = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRol.getIdRol());

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el rol: " + e.getMessage());
        }

        return eliminar;
    }

    // 5. ACTIVAR ROL
    public boolean activarRol(Rol miRol) {
        boolean activar = false;

        String querySql = "UPDATE Rol SET descripcion = 'Activo' WHERE id_rol = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRol.getIdRol());

            if (ps.executeUpdate() > 0) {
                activar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al activar el rol: " + e.getMessage());
        }

        return activar;
    }

    // 6. INACTIVAR ROL
    public boolean inactivarRol(Rol miRol) {
        boolean inactivar = false;

        String querySql = "UPDATE Rol SET descripcion = 'Inactivo' WHERE id_rol = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miRol.getIdRol());

            if (ps.executeUpdate() > 0) {
                inactivar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al inactivar el rol: " + e.getMessage());
        }

        return inactivar;
    }
}