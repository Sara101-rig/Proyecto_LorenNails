package Controlador;

public class TestConexion {
    public static void main(String[] args) {
        Conexion c = new Conexion();
        if (c.getConn() != null) {
            System.out.println("Conexión exitosa");
        } else {
            System.out.println("Conexión fallida");
        }
    }
}