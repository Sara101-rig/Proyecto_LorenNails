/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.TipoDocumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TipoDocumentoDAO {

    private final Conexion conect = new Conexion();

    // =========================
    // CONSULTAR
    // =========================
    public TipoDocumento consultarTipoDocumento(int idTipoDocumento) {

        TipoDocumento miTipoDocumento = null;

        String querySql = "SELECT id_tipo_documento, descripcion "
                + "FROM tipo_documento "
                + "WHERE id_tipo_documento = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idTipoDocumento);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    miTipoDocumento = new TipoDocumento();

                    miTipoDocumento.setIdTipoDocumento(
                            rs.getInt("id_tipo_documento")
                    );

                    miTipoDocumento.setDescripcion(
                            rs.getString("descripcion")
                    );
                }
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al consultar tipo de documento: "
                    + e.getMessage()
            );
        }

        return miTipoDocumento;
    }

    // =========================
    // INSERTAR
    // =========================
    public boolean insertarTipoDocumento(TipoDocumento miTipoDocumento) {

        boolean insertar = false;

        String querySql = "INSERT INTO tipo_documento (descripcion) "
                + "VALUES (?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miTipoDocumento.getDescripcion());

            int filas = ps.executeUpdate();

            if (filas > 0) {

                insertar = true;

                System.out.println(
                        "Tipo de documento insertado correctamente"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al insertar tipo de documento: "
                    + e.getMessage()
            );
        }

        return insertar;
    }

    // =========================
    // ACTUALIZAR
    // =========================
    public boolean actualizarTipoDocumento(TipoDocumento miTipoDocumento) {

        boolean actualizar = false;

        String querySql = "UPDATE tipo_documento "
                + "SET descripcion = ? "
                + "WHERE id_tipo_documento = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miTipoDocumento.getDescripcion());

            ps.setInt(2, miTipoDocumento.getIdTipoDocumento());

            int filas = ps.executeUpdate();

            if (filas > 0) {

                actualizar = true;

                System.out.println(
                        "Tipo de documento actualizado correctamente"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al actualizar tipo de documento: "
                    + e.getMessage()
            );
        }

        return actualizar;
    }

    // =========================
    // ELIMINAR
    // =========================
    public boolean eliminarTipoDocumento(TipoDocumento miTipoDocumento) {

        boolean eliminar = false;

        String querySql = "DELETE FROM tipo_documento "
                + "WHERE id_tipo_documento = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miTipoDocumento.getIdTipoDocumento());

            int filas = ps.executeUpdate();

            if (filas > 0) {

                eliminar = true;

                System.out.println(
                        "Tipo de documento eliminado correctamente"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error al eliminar tipo de documento: "
                    + e.getMessage()
            );
        }

        return eliminar;
    }
}
