package Controlador;

import Modelo.Dia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DiaDAO {
        
    private final Conexion conect = new Conexion();
    
    public Dia consultarDias(int idDia) {
        Dia miDia = null; 
        
        // CORREGIDO: Sintaxis SQL corregida para buscar por id_dias
        String querySql = "SELECT id_dias, nombre_dia FROM Dia WHERE id_dias = ?";
        
        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {
            
            ps.setInt(1, idDia);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miDia = new Dia();
                    miDia.setIdDias(rs.getInt("id_dias"));
                    miDia.setNombreDia(rs.getString("nombre_dia"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el día: " + e.getMessage());
        }
        
        return miDia;
    }
    
    public boolean insertarDias(Dia miDia) {
        boolean insertar = false;
        
        try (Connection conn = conect.getConn()) {
            String querySql = "INSERT INTO Dia(nombre_dia) VALUES (?)";
            
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, miDia.getNombreDia());
            
            ps.executeUpdate();
            insertar = true;
            System.out.println("Dato insertado");
            
        } catch (Exception e) {
            System.out.println("Error al insertar el día: " + e.getMessage());
        }
        
        return insertar;
    }

    public boolean actualizarDias(Dia miDia) {
        boolean actualizar = false;
        
        try (Connection conn = conect.getConn()) {
            String querySql = "UPDATE Dia SET nombre_dia = ? WHERE id_dias = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);

            // CORREGIDO: Se asignan ambos parámetros (el nombre y el id)
            ps.setString(1, miDia.getNombreDia());
            ps.setInt(2, miDia.getIdDias());
            
            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar: " + e.getMessage());
        }

        return actualizar;
    }

    public boolean inactivarDias(Dia miDia) {
        boolean inactivar = false;

        String querySql = "UPDATE Dia SET nombre_dia = 'Inactivo' WHERE id_dias = ?";

        try (Connection conn = conect.getConn()) {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, miDia.getIdDias());

            if (ps.executeUpdate() > 0) {
                inactivar = true;
            }
        } catch (Exception e) {
            System.out.println("Error al inactivar: " + e.getMessage());
        }

        return inactivar;
    }

    public boolean activarDias(Dia miDia) {
        boolean activar = false;
        String querySql = "UPDATE Dia SET nombre_dia = 'Activo' WHERE id_dias = ?";

        try (Connection conn = conect.getConn()) {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, miDia.getIdDias());

            if (ps.executeUpdate() > 0) {
                activar = true;
            }
        } catch (Exception e) {
            System.out.println("Error al activar: " + e.getMessage());
        }

        return activar;
    }

    public boolean eliminarDias(Dia miDia) {
        boolean eliminar = false;
        String querySql = "DELETE FROM Dia WHERE id_dias = ?";

        try (Connection conn = conect.getConn()) {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, miDia.getIdDias());

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
        }

        return eliminar;
    }
}