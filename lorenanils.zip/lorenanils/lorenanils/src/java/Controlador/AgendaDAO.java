/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Agenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AgendaDAO {

    private final Conexion conect = new Conexion();


    public Agenda consultarAgenda(int idAgenda) {
        Agenda miAgenda = null;

        String querySql = "SELECT id_agenda, fecha, estado, observaciones, usuario_id_usuario, servicio_id_servicios, horario_id_horarios, ubicacion_id_ubicacion "
                + "FROM agenda "
                + "WHERE id_agenda = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idAgenda);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miAgenda = new Agenda();
                    miAgenda.setIdAgenda(rs.getInt("id_agenda"));
                    miAgenda.setFecha(rs.getDate("fecha"));
                    miAgenda.setEstado(rs.getString("estado"));
                    miAgenda.setObservaciones(rs.getString("observaciones"));
                    miAgenda.setUsuarioidUsuario(rs.getInt("usuario_id_usuario"));
                    miAgenda.setServicioIdServicios(rs.getInt("servicio_id_servicios"));
                    miAgenda.setHorarioIdHorarios(rs.getInt("horario_id_horarios"));
                    miAgenda.setUbicacionIdUbicacion(rs.getInt("ubicacion_id_ubicacion"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al consultar la agenda: " + e.getMessage());
        }

        return miAgenda;
    }


    public boolean insertarAgenda(Agenda miAgenda) {
        boolean insertar = false;

        String querySql = "INSERT INTO agenda (fecha, estado, observaciones, usuario_id_usuario, servicio_id_servicios, horario_id_horarios, ubicacion_id_ubicacion) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setDate(1, miAgenda.getFecha());
            ps.setString(2, miAgenda.getEstado());
            ps.setString(3, miAgenda.getObservaciones());
            ps.setInt(4, miAgenda.getUsuarioidUsuario());
            ps.setInt(5, miAgenda.getServicioIdServicios());
            ps.setInt(6, miAgenda.getHorarioIdHorarios());
            ps.setInt(7, miAgenda.getUbicacionIdUbicacion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Agenda registrada con éxito");

        } catch (SQLException e) {
            System.out.println("Error al registrar la agenda: " + e.getMessage());
        }

        return insertar;
    }


    public boolean actualizarAgenda(Agenda miAgenda) {
        boolean actualizar = false;

        String querySql = "UPDATE agenda SET fecha = ?, estado = ?, observaciones = ?, usuario_id_usuario = ?, servicio_id_servicios = ?, horario_id_horarios = ?, ubicacion_id_ubicacion = ? WHERE id_agenda = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setDate(1, miAgenda.getFecha());
            ps.setString(2, miAgenda.getEstado());
            ps.setString(3, miAgenda.getObservaciones());
            ps.setInt(4, miAgenda.getUsuarioidUsuario());
            ps.setInt(5, miAgenda.getServicioIdServicios());
            ps.setInt(6, miAgenda.getHorarioIdHorarios());
            ps.setInt(7, miAgenda.getUbicacionIdUbicacion());
            ps.setInt(8, miAgenda.getIdAgenda());

            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar la agenda: " + e.getMessage());
        }

        return actualizar;
    }


    public boolean eliminarAgenda(int idAgenda) {
        boolean eliminar = false;

        String querySql = "DELETE FROM agenda WHERE id_agenda = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idAgenda);

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar la agenda: " + e.getMessage());
        }

        return eliminar;
    }
}