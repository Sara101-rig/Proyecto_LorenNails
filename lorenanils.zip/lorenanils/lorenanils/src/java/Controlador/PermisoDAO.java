/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Permiso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PermisoDAO {

    private final Conexion conect = new Conexion();

   
    public Permiso consultarPermiso(int idPermiso) {
        Permiso miPermiso = null;

        String querySql = "SELECT id_permiso, nombre, descripcion "
                + "FROM Permiso WHERE id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idPermiso);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miPermiso = new Permiso();
                    miPermiso.setIdPermiso(rs.getInt("id_permiso"));
                    miPermiso.setNombre(rs.getString("nombre"));
                    miPermiso.setDescripcion(rs.getString("descripcion"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al consultar el permiso: " + e.getMessage());
        }

        return miPermiso;
    }

 
    public boolean insertarPermisos(Permiso miPermiso) {
        boolean insertar = false;

        String querySql = "INSERT INTO Permiso(nombre, descripcion) VALUES (?, ?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miPermiso.getNombre());
            ps.setString(2, miPermiso.getDescripcion());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Permiso insertado");

        } catch (SQLException e) {
            System.out.println("Error al insertar el permiso: " + e.getMessage());
        }

        return insertar;
    }

                                
    public boolean actualizarPermisos(Permiso miPermiso) {
        boolean actualizar = false;

        String querySql = "UPDATE Permiso SET nombre = ?, descripcion = ? WHERE id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miPermiso.getNombre());
            ps.setString(2, miPermiso.getDescripcion());
            ps.setInt(3, miPermiso.getIdPermiso());

            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el permiso: " + e.getMessage());
        }

        return actualizar;
    }


    public boolean eliminarPermisos(Permiso miPermiso) {
        boolean eliminar = false;

        String querySql = "DELETE FROM Permiso WHERE id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miPermiso.getIdPermiso());

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el permiso: " + e.getMessage());
        }

        return eliminar;
    }
    
    
    public boolean inactivarPermisos(Permiso miPermiso) {
        boolean inactivar = false;

        
        String querySql = "UPDATE Permiso SET descripcion = 'Inactivo' WHERE id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miPermiso.getIdPermiso());

            if (ps.executeUpdate() > 0) {
                inactivar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al inactivar el permiso: " + e.getMessage());
        }

        return inactivar;
    }


    public boolean activarPermisos(Permiso miPermiso) {
        boolean activar = false;

       
        String querySql = "UPDATE Permiso SET descripcion = 'Activo' WHERE id_permiso = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miPermiso.getIdPermiso());

            if (ps.executeUpdate() > 0) {
                activar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al activar el permiso: " + e.getMessage());
        }

        return activar;
    }
}