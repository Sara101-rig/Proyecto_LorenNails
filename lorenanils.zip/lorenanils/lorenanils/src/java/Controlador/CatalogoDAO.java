/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Catalogo;
import java.sql.*;
public class CatalogoDAO {

    private final Conexion conect = new Conexion();

    public Catalogo consultarCatalogo(int idCatalogo) {

        Catalogo miCatalogo = null;

        String querySql = "SELECT id_catalogo, descripcion, imagen, "
                + "categoria_id_categoria FROM catalogo "
                + "WHERE id_catalogo = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idCatalogo);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    miCatalogo = new Catalogo();

                    miCatalogo.setIdCatalogo(
                            rs.getInt("id_catalogo"));

                    miCatalogo.setDescripcion(
                            rs.getString("descripcion"));

                    miCatalogo.setImagen(
                            rs.getString("imagen"));

                    miCatalogo.setCategoriaIdCategoria(
                            rs.getInt("categoria_id_categoria"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar catálogo: " + e.getMessage());
        }

        return miCatalogo;
    }

    public boolean insertarCatalogo(Catalogo miCatalogo) {

        boolean insertar = false;

        String querySql = "INSERT INTO catalogo "
                + "(descripcion, imagen, categoria_id_categoria) "
                + "VALUES (?, ?, ?)";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miCatalogo.getDescripcion());
            ps.setString(2, miCatalogo.getImagen());
            ps.setInt(3, miCatalogo.getCategoriaIdCategoria());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                insertar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al insertar catálogo: " + e.getMessage());
        }

        return insertar;
    }

    public boolean actualizarCatalogo(Catalogo miCatalogo) {

        boolean actualizar = false;

        String querySql = "UPDATE catalogo SET descripcion = ?, "
                + "imagen = ?, categoria_id_categoria = ? "
                + "WHERE id_catalogo = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setString(1, miCatalogo.getDescripcion());
            ps.setString(2, miCatalogo.getImagen());
            ps.setInt(3, miCatalogo.getCategoriaIdCategoria());
            ps.setInt(4, miCatalogo.getIdCatalogo());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar catálogo: " + e.getMessage());
        }

        return actualizar;
    }

    public boolean eliminarCatalogo(Catalogo miCatalogo) {

        boolean eliminar = false;

        String querySql = "DELETE FROM catalogo WHERE id_catalogo = ?";

        try (Connection conn = conect.getConn();
                PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, miCatalogo.getIdCatalogo());

            int filas = ps.executeUpdate();

            if (filas > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar catálogo: " + e.getMessage());
        }

        return eliminar;
    }
}
