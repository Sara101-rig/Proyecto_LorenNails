/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Horario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HorarioDAO {

    private final Conexion conect = new Conexion();


    public Horario consultarHorario(int idHorarios) {
        Horario miHorario = null;

        String querySql = "SELECT id_horarios, hora_inicio, hora_fin, disponibilidad, dia_id_dias "
                + "FROM horario "
                + "WHERE id_horarios = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idHorarios);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miHorario = new Horario();
                    miHorario.setIdHorarios(rs.getInt("id_horarios"));
                    miHorario.setHoraInicio(rs.getTime("hora_inicio"));
                    miHorario.setHoraFin(rs.getTime("hora_fin"));
                    miHorario.setDisponibilidad(rs.getString("disponibilidad"));
                    miHorario.setDiaIdDias(rs.getInt("dia_id_dias"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al consultar el horario: " + e.getMessage());
        }

        return miHorario;
    }

    // 2. INSERTAR HORARIO
    public boolean insertarHorario(Horario miHorario) {
        boolean insertar = false;

        String querySql = "INSERT INTO horario (hora_inicio, hora_fin, disponibilidad, dia_id_dias) VALUES (?, ?, ?, ?)";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setTime(1, miHorario.getHoraInicio());
            ps.setTime(2, miHorario.getHoraFin());
            ps.setString(3, miHorario.getDisponibilidad());
            ps.setInt(4, miHorario.getDiaIdDias());

            ps.executeUpdate();
            insertar = true;
            System.out.println("Horario registrado con éxito");

        } catch (SQLException e) {
            System.out.println("Error al registrar el horario: " + e.getMessage());
        }

        return insertar;
    }

    // 3. ACTUALIZAR HORARIO
    public boolean actualizarHorario(Horario miHorario) {
        boolean actualizar = false;

        String querySql = "UPDATE horario SET hora_inicio = ?, hora_fin = ?, disponibilidad = ?, dia_id_dias = ? WHERE id_horarios = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setTime(1, miHorario.getHoraInicio());
            ps.setTime(2, miHorario.getHoraFin());
            ps.setString(3, miHorario.getDisponibilidad());
            ps.setInt(4, miHorario.getDiaIdDias());
            ps.setInt(5, miHorario.getIdHorarios());

            if (ps.executeUpdate() > 0) {
                actualizar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar el horario: " + e.getMessage());
        }

        return actualizar;
    }

    // 4. ELIMINAR HORARIO
    public boolean eliminarHorario(int idHorarios) {
        boolean eliminar = false;

        String querySql = "DELETE FROM horario WHERE id_horarios = ?";

        try (Connection conn = conect.getConn();
             PreparedStatement ps = conn.prepareStatement(querySql)) {

            ps.setInt(1, idHorarios);

            if (ps.executeUpdate() > 0) {
                eliminar = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al eliminar el horario: " + e.getMessage());
        }

        return eliminar;
    }

    public boolean activarHorario(Horario miHorario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean inactivarHorario(Horario miHorario) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}