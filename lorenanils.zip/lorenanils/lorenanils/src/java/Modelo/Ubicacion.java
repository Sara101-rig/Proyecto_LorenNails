/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Ubicacion {

    public int getIdUbicacion() {
        return idUbicacion;
    }

    public void setIdUbicacion(int idUbicacion) {
        this.idUbicacion = idUbicacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public int getUsuarioIdUsuario() {
        return UsuarioIdUsuario;
    }

    public void setUsuarioIdUsuario(int UsuarioIdUsuario) {
        this.UsuarioIdUsuario = UsuarioIdUsuario;
    }

   private int idUbicacion;
   private String direccion;
   private String referencia;
   private int UsuarioIdUsuario;
   
    public static void main(String[] args) {
        
    }

    public String getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
