/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modelo;

import java.math.BigDecimal;

/**
 *
 * @author Aprendiz
 */
public class Servicio {

    public int getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(int idServicio) {
        this.idServicio = idServicio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public int getCatalogoidCatalogo() {
        return catalogoidCatalogo;
    }

    public void setCatalogoidCatalogo(int catalogoidCatalogo) {
        this.catalogoidCatalogo = catalogoidCatalogo;
    }
    private int idServicio;
    private String nombre;
    private String descripcion;
    private BigDecimal precio;
    private int catalogoidCatalogo;
    

    
    public static void main(String[] args) {
        // TODO code application logic here
    }

    
}
