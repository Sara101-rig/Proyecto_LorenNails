/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Modelo;
import java.sql.Date;

public class Agenda {

    public int getIdAgenda() {
        return idAgenda;
    }

    public void setIdAgenda(int idAgenda) {
        this.idAgenda = idAgenda;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getUsuarioidUsuario() {
        return usuarioidUsuario;
    }

    public void setUsuarioidUsuario(int usuarioidUsuario) {
        this.usuarioidUsuario = usuarioidUsuario;
    }

    public int getServicioIdServicios() {
        return servicioIdServicios;
    }

    public void setServicioIdServicios(int servicioIdServicios) {
        this.servicioIdServicios = servicioIdServicios;
    }

    public int getHorarioIdHorarios() {
        return horarioIdHorarios;
    }

    public void setHorarioIdHorarios(int horarioIdHorarios) {
        this.horarioIdHorarios = horarioIdHorarios;
    }

    public int getUbicacionIdUbicacion() {
        return ubicacionIdUbicacion;
    }

    public void setUbicacionIdUbicacion(int ubicacionIdUbicacion) {
        this.ubicacionIdUbicacion = ubicacionIdUbicacion;
    }
    private int idAgenda;
    private Date fecha;
    private String estado;
    private String observaciones;
    private int usuarioidUsuario;
    private int servicioIdServicios;
    private int horarioIdHorarios;
    private int ubicacionIdUbicacion;
    

 
  
    public static void main(String[] args) {
     
    }

    public void setHora(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setDescripcion(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
 