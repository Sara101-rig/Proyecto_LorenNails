package Modelo;

public class RolHasPermiso {

    private int rolIdRol;
    private int permisoIdPermiso;

    public int getRolIdRol() {
        return rolIdRol;
    }

    public void setRolIdRol(int rolIdRol) {
        this.rolIdRol = rolIdRol;
    }

    public int getPermisoIdPermiso() {
        return permisoIdPermiso;
    }

    public void setPermisoIdPermiso(int permisoIdPermiso) {
        this.permisoIdPermiso = permisoIdPermiso;
    }
}