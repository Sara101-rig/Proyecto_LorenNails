package Modelo;

import java.math.BigDecimal;
import java.sql.Time;

public class Horario {

    private int idHorarios;
    private Time horaInicio;
    private Time horaFin; 
    private String disponibilidad; 
    private int diaIdDias;

    // Getters y Setters
    public int getIdHorarios() {
        return idHorarios;
    }

    public void setIdHorarios(int idHorarios) {
        this.idHorarios = idHorarios;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    
    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public int getDiaIdDias() {
        return diaIdDias;
    }

    public void setDiaIdDias(int diaIdDias) {
        this.diaIdDias = diaIdDias;
    }

    public BigDecimal getTimeHoraInicio() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public BigDecimal getTimeHoraFin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}