/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CatalogoDAO;
import Modelo.Catalogo;
import java.util.Scanner;

public class PruebasInsertarCatalogo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Catalogo miCatalogo = new Catalogo();
        CatalogoDAO DAO = new CatalogoDAO();

        System.out.print("Ingrese la descripcion del catalogo: ");
        miCatalogo.setDescripcion(sc.nextLine());

        System.out.print("Ingrese la imagen del catalogo: ");
        miCatalogo.setImagen(sc.nextLine());

        System.out.print("Ingrese el ID de la categoria: ");
        miCatalogo.setCategoriaIdCategoria(sc.nextInt());

        boolean resultado = DAO.insertarCatalogo(miCatalogo);

        if (resultado) {
            System.out.println("Catalogo insertado correctamente");
        } else {
            System.out.println("No se pudo insertar el catalogo");
        }
    }
}