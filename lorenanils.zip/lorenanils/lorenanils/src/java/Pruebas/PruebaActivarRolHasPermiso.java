/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.RolHasPermisoDAO;
import Modelo.RolHasPermiso;
import java.util.Scanner;

public class PruebaActivarRolHasPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        RolHasPermiso miRolHasPermiso = new RolHasPermiso();
        RolHasPermisoDAO dao = new RolHasPermisoDAO();

        System.out.println("Por favor ingresar el ID del rol");
        miRolHasPermiso.setRolIdRol(sc.nextInt());

        System.out.println("Por favor ingresar el ID del permiso");
        miRolHasPermiso.setPermisoIdPermiso(sc.nextInt());

        boolean resultado = dao.activarRolHasPermiso(miRolHasPermiso);

        if (resultado) {
            System.out.println("La activación se guardó correctamente");
        } else {
            System.out.println("La activación no se pudo guardar correctamente");
        }
    }
}