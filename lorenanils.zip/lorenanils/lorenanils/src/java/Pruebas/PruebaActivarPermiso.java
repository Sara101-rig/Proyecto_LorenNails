/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaActivarPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Permiso miPermiso = new Permiso();
        PermisoDAO dao = new PermisoDAO();

        System.out.println("Por favor ingresar su ID a activar");
        miPermiso.setIdPermiso(sc.nextInt());
        sc.nextLine();

        boolean resultado = dao.activarPermisos(miPermiso);

        if (resultado) {
            System.out.println("La activación se guardó correctamente");
        } else {
            System.out.println("La activación no se pudo guardar correctamente");
        }
    }
}