package Pruebas;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.sql.Time;
import java.util.Scanner;

public class PruebaInsertarHorario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Horario miHorario = new Horario();
        HorarioDAO dao = new HorarioDAO();

        System.out.print("Por favor ingrese la hora de inicio ");
       
        miHorario.setHoraInicio(Time.valueOf(sc.nextLine()));

        System.out.print("Por favor ingrese la hora de fin ");
        miHorario.setHoraFin(Time.valueOf(sc.nextLine()));

        System.out.print("Por favor ingrese la disponibilidad: ");
        miHorario.setDisponibilidad(sc.nextLine());

        System.out.print("Por favor ingrese el ID del día asociado: ");
        miHorario.setDiaIdDias(sc.nextInt());
        sc.nextLine(); 
        boolean resultado = dao.insertarHorario(miHorario);

        if (resultado) {
            System.out.println("El horario se insertó correctamente");
        } else {
            System.out.println("Error al insertar el horario");
        }
    }
}