package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebasInsertarTipoDocumento {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TipoDocumento miTipoDocumento = new TipoDocumento();
        TipoDocumentoDAO DAO = new TipoDocumentoDAO();

        System.out.print("Ingrese la descripción del tipo de documento: ");
        miTipoDocumento.setDescripcion(sc.nextLine());

        boolean resultado = DAO.insertarTipoDocumento(miTipoDocumento);

        if (resultado) {
            System.out.println("Tipo de documento insertado correctamente");
        } else {
            System.out.println("No se pudo insertar el tipo de documento");
        }
    }
}