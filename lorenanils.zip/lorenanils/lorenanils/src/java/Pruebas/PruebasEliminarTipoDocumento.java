/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebasEliminarTipoDocumento {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TipoDocumento miTipoDocumento = new TipoDocumento();
        TipoDocumentoDAO DAO = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento que desea eliminar: ");
        miTipoDocumento.setIdTipoDocumento(sc.nextInt());

        boolean resultado = DAO.eliminarTipoDocumento(miTipoDocumento);

        if (resultado) {

            System.out.println(
                    "Tipo de documento eliminado correctamente"
            );

        } else {

            System.out.println(
                    "No se pudo eliminar el tipo de documento"
            );
        }
    }
}
