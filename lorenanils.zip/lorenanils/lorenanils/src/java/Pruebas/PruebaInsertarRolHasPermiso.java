/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolHasPermisoDAO;
import Modelo.RolHasPermiso;
import java.util.Scanner;

public class PruebaInsertarRolHasPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        RolHasPermiso miRolHasPermiso = new RolHasPermiso();
        RolHasPermisoDAO dao = new RolHasPermisoDAO();

        System.out.println("Ingrese el ID del rol:");
        miRolHasPermiso.setRolIdRol(sc.nextInt());

        System.out.println("Ingrese el ID del permiso:");
        miRolHasPermiso.setPermisoIdPermiso(sc.nextInt());

        boolean resultado = dao.insertarRolHasPermiso(miRolHasPermiso);

        if (resultado) {
            System.out.println("Rol y permiso se guardaron correctamente");

        } else {
            System.out.println("Rol y permiso no se pudieron guardar correctamente");
        }
    }
}