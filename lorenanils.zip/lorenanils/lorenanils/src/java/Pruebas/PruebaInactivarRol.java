/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaInactivarRol {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Rol miRol = new Rol();
        RolDAO dao = new RolDAO();

        System.out.println("Por favor ingresar su ID a inactivar");
        miRol.setIdRol(sc.nextInt());
        sc.nextLine();

        boolean resultado = dao.inactivarRol(miRol);

        if (resultado) {
            System.out.println("La inactivación se guardó correctamente");

        } else {
            System.out.println("La inactivación no se pudo guardar correctamente");
        }
    }
}