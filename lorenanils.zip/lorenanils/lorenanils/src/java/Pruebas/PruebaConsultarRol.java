/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner; // 1. Importar la clase Scanner

public class PruebaConsultarRol {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RolDAO rolDAO = new RolDAO();


        System.out.println("Por favor ingrese el ID del rol a consultar:");
        int idRol = sc.nextInt();
        sc.nextLine(); 

        Rol miRol = rolDAO.consultarRol(idRol);

        if (miRol != null) {
            System.out.println("ID Rol: " + miRol.getIdRol());
            System.out.println("Nombre: " + miRol.getNombre());
            System.out.println("Descripción: " + miRol.getDescripcion());

        } else {
            System.out.println("No se encontró el rol.");
        }
    }
}