package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebasActualizarTipoDocumento {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TipoDocumento miTipoDocumento = new TipoDocumento();
        TipoDocumentoDAO DAO = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento que desea actualizar: ");
        miTipoDocumento.setIdTipoDocumento(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese la nueva descripción: ");
        miTipoDocumento.setDescripcion(sc.nextLine());

        boolean resultado = DAO.actualizarTipoDocumento(miTipoDocumento);

        if (resultado) {

            System.out.println(
                    "Tipo de documento actualizado correctamente"
            );

        } else {

            System.out.println(
                    "No se pudo actualizar el tipo de documento"
            );
        }
    }
}
