package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebasConsultarTipoDocumento {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        TipoDocumentoDAO DAO = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento que desea consultar: ");
        int id = sc.nextInt();

        TipoDocumento miTipoDocumento = DAO.consultarTipoDocumento(id);

        if (miTipoDocumento != null) {

            System.out.println("Tipo de documento encontrado");
            System.out.println("ID: "
                    + miTipoDocumento.getIdTipoDocumento());
            System.out.println("Descripción: "
                    + miTipoDocumento.getDescripcion());

        } else {

            System.out.println("No se encontró el tipo de documento");
        }
    }
}