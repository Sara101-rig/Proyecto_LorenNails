/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UbicacionDAO;
import Modelo.Ubicacion;
import java.util.Scanner;

public class PruebasEliminarUbicacion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Ubicacion miUbicacion = new Ubicacion();
        UbicacionDAO DAO = new UbicacionDAO();

        System.out.print("Ingrese el ID de la ubicacion que desea eliminar: ");
        miUbicacion.setIdUbicacion(sc.nextInt());

        boolean resultado = DAO.eliminarUbicacion(miUbicacion);

        if (resultado) {
            System.out.println("Ubicacion eliminada correctamente");
        } else {
            System.out.println("No se pudo eliminar la ubicacion");
        }
    }
}