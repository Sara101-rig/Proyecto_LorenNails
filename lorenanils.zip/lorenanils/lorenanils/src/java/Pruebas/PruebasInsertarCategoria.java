/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebasInsertarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Categoria miCategoria = new Categoria();
        CategoriaDAO DAO = new CategoriaDAO();

        System.out.print("Ingrese la descripcion de la categoria: ");
        miCategoria.setDescripcion(sc.nextLine());

        boolean resultado = DAO.insertarCategoria(miCategoria);

        if (resultado) {
            System.out.println("Categoria insertada correctamente");
        } else {
            System.out.println("No se pudo insertar la categoria");
        }
    }
}