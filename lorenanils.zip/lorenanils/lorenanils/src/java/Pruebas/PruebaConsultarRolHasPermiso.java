/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolHasPermisoDAO;
import Modelo.RolHasPermiso;

public class PruebaConsultarRolHasPermiso {

    public static void main(String[] args) {

        RolHasPermisoDAO rolHasPermisoDAO = new RolHasPermisoDAO();

        int idRol = 1;
        int idPermiso = 1;

        RolHasPermiso miRolHasPermiso =
                rolHasPermisoDAO.consultarRolHasPermiso(idRol, idPermiso);

        if (miRolHasPermiso != null) {

            System.out.println("ID Rol: "
                    + miRolHasPermiso.getRolIdRol());

            System.out.println("ID Permiso: "
                    + miRolHasPermiso.getPermisoIdPermiso());

        } else {

            System.out.println("No se encontró la relación entre el rol y el permiso.");
        }
    }
}