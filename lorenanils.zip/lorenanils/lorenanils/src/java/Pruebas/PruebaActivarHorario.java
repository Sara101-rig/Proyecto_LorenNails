/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.util.Scanner;

public class PruebaActivarHorario {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Horario miHorario = new Horario();
        HorarioDAO dao = new HorarioDAO();

        System.out.println("Por favor ingresar su ID a activar");
        miHorario.setIdHorarios(sc.nextInt());
        sc.nextLine();

        boolean resultado = dao.activarHorario(miHorario);

        if (resultado) {
            System.out.println("La activación se guardó correctamente");
        } else {
            System.out.println("La activación no se pudo guardar correctamente");
        }
    }
}