package Pruebas;

import Controlador.DiaDAO;
import Modelo.Dia;
import java.util.Scanner; // 1. Importar el Scanner

public class PruebaConsultarDia {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // 2. Crear el objeto Scanner
        DiaDAO diaDAO = new DiaDAO();

        // 3. Pedir el ID por consola
        System.out.print("Por favor ingrese el ID del día a consultar: ");
        int idDia = sc.nextInt();
        sc.nextLine(); // Limpiar el buffer

        Dia miDia = diaDAO.consultarDias(idDia);

        if (miDia != null) {
            System.out.println("ID Dia: " + miDia.getIdDias());
            System.out.println("Nombre: " + miDia.getNombreDia());

        } else {
            System.out.println("No se encontró el día.");
        }
    }
}