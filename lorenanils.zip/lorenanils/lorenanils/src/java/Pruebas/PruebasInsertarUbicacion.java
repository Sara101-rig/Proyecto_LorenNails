/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UbicacionDAO;
import Modelo.Ubicacion;
import java.util.Scanner;

public class PruebasInsertarUbicacion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Ubicacion miUbicacion = new Ubicacion();
        UbicacionDAO DAO = new UbicacionDAO();

        System.out.print("Ingrese la direccion: ");
        miUbicacion.setDireccion(sc.nextLine());

        System.out.print("Ingrese la referencia: ");
        miUbicacion.setReferencia(sc.nextLine());

        System.out.print("Ingrese el ID del usuario: ");
        miUbicacion.setUsuarioIdUsuario(sc.nextInt());

        boolean resultado = DAO.insertarUbicacion(miUbicacion);

        if (resultado) {
            System.out.println("Ubicacion insertada correctamente");
        } else {
            System.out.println("No se pudo insertar la ubicacion");
        }
    }
}