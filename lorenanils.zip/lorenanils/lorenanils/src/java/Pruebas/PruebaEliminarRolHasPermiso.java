/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolHasPermisoDAO;
import Modelo.RolHasPermiso;
import java.util.Scanner;

public class PruebaEliminarRolHasPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        RolHasPermiso miRolHasPermiso = new RolHasPermiso();
        RolHasPermisoDAO dao = new RolHasPermisoDAO();

        System.out.println("Por favor ingresar el ID del rol a eliminar");
        miRolHasPermiso.setRolIdRol(sc.nextInt());

        System.out.println("Por favor ingresar el ID del permiso a eliminar");
        miRolHasPermiso.setPermisoIdPermiso(sc.nextInt());

        boolean resultado = dao.eliminarRolHasPermiso(miRolHasPermiso);

        if (resultado) {
            System.out.println("La relación rol-permiso se eliminó correctamente");
        } else {
            System.out.println("La relación rol-permiso no se pudo eliminar");
        }
    }
}