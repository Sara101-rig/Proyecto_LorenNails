/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebasConsultarUsuario {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        UsuarioDAO DAO = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario que desea consultar: ");
        int idUsuario = sc.nextInt();

        Usuario miUsuario = DAO.consultarUsuario(idUsuario);

        if (miUsuario != null) {

            System.out.println("Usuario encontrado");
            System.out.println("ID: "
                    + miUsuario.getIdUsuario());
            System.out.println("Nombre: "
                    + miUsuario.getNombre());
            System.out.println("Apellido: "
                    + miUsuario.getApellido());
            System.out.println("Numero de identidad: "
                    + miUsuario.getNumeroIdentidad());
            System.out.println("Fecha de nacimiento: "
                    + miUsuario.getFechaNacimiento());
            System.out.println("Correo: "
                    + miUsuario.getCorreo());
            System.out.println("Telefono: "
                    + miUsuario.getTelefono());
            System.out.println("Direccion: "
                    + miUsuario.getDireccion());
            System.out.println("Estado: "
                    + miUsuario.getEstado());
            System.out.println("Tipo de documento: "
                    + miUsuario.getTipoDocumentoIdTipoDocumento());
            System.out.println("Rol: "
                    + miUsuario.getIdRol());

        } else {

            System.out.println("No se encontró el usuario");
        }
    }
}