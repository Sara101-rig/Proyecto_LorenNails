/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.Conexion;
import java.sql.Connection;

public class Pruebaconexion {
    
    public static void main(String[] args) {
        
Conexion Sara = new Conexion();
Connection con = Sara.getConn();
    }
}
