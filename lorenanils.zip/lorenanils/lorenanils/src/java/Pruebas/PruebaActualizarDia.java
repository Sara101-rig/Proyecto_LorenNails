 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.DiaDAO;
import Modelo.Dia;
import java.util.Scanner;

public class PruebaActualizarDia {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Dia miDia = new Dia();
        DiaDAO dao = new DiaDAO();

        System.out.println("Por favor ingresar su ID para actualizar");
        miDia.setIdDias(sc.nextInt());
        sc.nextLine();

        System.out.print("Por favor ingrese el nombre del día: ");
        miDia.setNombreDia(sc.nextLine());

        boolean resultado = dao.actualizarDias(miDia);

        if (resultado) {
            System.out.println("La actualización se guardó correctamente");
        } else {
            System.out.println("La actualización no se pudo guardar correctamente");
        }
    }
}