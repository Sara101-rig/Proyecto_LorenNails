/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebasConsultarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        CategoriaDAO DAO = new CategoriaDAO();

        System.out.print("Ingrese el ID de la categoria que desea consultar: ");
        int idCategoria = sc.nextInt();

        Categoria miCategoria = DAO.consultarCategoria(idCategoria);

        if (miCategoria != null) {

            System.out.println("Categoria encontrada");
            System.out.println("ID: "
                    + miCategoria.getIdCategoria());
            System.out.println("Descripcion: "
                    + miCategoria.getDescripcion());

        } else {

            System.out.println("No se encontro la categoria");
        }
    }
}