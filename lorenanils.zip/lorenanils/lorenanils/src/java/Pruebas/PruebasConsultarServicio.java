/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.ServicioDAO;
import Modelo.Servicio;
import java.util.Scanner;

public class PruebasConsultarServicio {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ServicioDAO DAO = new ServicioDAO();

        System.out.print("Ingrese el ID del servicio que desea consultar: ");
        int idServicio = sc.nextInt();

        Servicio miServicio = DAO.consultarServicio(idServicio);

        if (miServicio != null) {

            System.out.println("Servicio encontrado");
            System.out.println("ID: "
                    + miServicio.getIdServicio());
            System.out.println("Nombre: "
                    + miServicio.getNombre());
            System.out.println("Descripcion: "
                    + miServicio.getDescripcion());
            System.out.println("Precio: "
                    + miServicio.getPrecio());
            System.out.println("ID Catalogo: "
                    + miServicio.getCatalogoidCatalogo());

        } else {

            System.out.println("No se encontro el servicio");
        }
    }
}
