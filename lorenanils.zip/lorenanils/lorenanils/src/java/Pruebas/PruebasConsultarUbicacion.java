/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UbicacionDAO;
import Modelo.Ubicacion;
import java.util.Scanner;

public class PruebasConsultarUbicacion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        UbicacionDAO DAO = new UbicacionDAO();

        System.out.print("Ingrese el ID de la ubicacion que desea consultar: ");
        int idUbicacion = sc.nextInt();

        Ubicacion miUbicacion = DAO.consultarUbicacion(idUbicacion);

        if (miUbicacion != null) {

            System.out.println("Ubicacion encontrada");
            System.out.println("ID: "
                    + miUbicacion.getIdUbicacion());
            System.out.println("Direccion: "
                    + miUbicacion.getDireccion());
            System.out.println("Referencia: "
                    + miUbicacion.getReferencia());
            System.out.println("ID Usuario: "
                    + miUbicacion.getUsuarioIdUsuario());

        } else {

            System.out.println("No se encontro la ubicacion");
        }
    }
}