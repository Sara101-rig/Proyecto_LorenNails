/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.ServicioDAO;
import Modelo.Servicio;
import java.util.Scanner;

public class PruebasActualizarServicio {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Servicio miServicio = new Servicio();
        ServicioDAO DAO = new ServicioDAO();

        System.out.print("Ingrese el ID del servicio que desea actualizar: ");
        miServicio.setIdServicio(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese el nuevo nombre: ");
        miServicio.setNombre(sc.nextLine());

        System.out.print("Ingrese la nueva descripcion: ");
        miServicio.setDescripcion(sc.nextLine());

        System.out.print("Ingrese el nuevo precio: ");
        miServicio.setPrecio(sc.nextBigDecimal());

        System.out.print("Ingrese el nuevo ID del catalogo: ");
        miServicio.setCatalogoidCatalogo(sc.nextInt());

        boolean resultado = DAO.actualizarServicio(miServicio);

        if (resultado) {
            System.out.println("Servicio actualizado correctamente");
        } else {
            System.out.println("No se pudo actualizar el servicio");
        }
    }
}
