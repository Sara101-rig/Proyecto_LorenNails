/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaActualizarPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Permiso miPermiso = new Permiso();
        PermisoDAO dao = new PermisoDAO();

        System.out.println("Por favor ingresar su ID para actualizar");
        miPermiso.setIdPermiso(sc.nextInt());
        sc.nextLine();

        System.out.print("Por favor ingrese el nombre del permiso: ");
        miPermiso.setNombre(sc.nextLine());

        System.out.print("Por favor ingrese la descripción del permiso: ");
        miPermiso.setDescripcion(sc.nextLine());

        boolean resultado = dao.actualizarPermisos(miPermiso);

        if (resultado) {
            System.out.println("La actualización se guardó correctamente");
        } else {
            System.out.println("La actualización no se pudo guardar correctamente");
        }
    }
}