/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaEliminarPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Permiso miPermiso = new Permiso();
        PermisoDAO dao = new PermisoDAO();

        System.out.println("Por favor ingresar su ID a eliminar");
        miPermiso.setIdPermiso(sc.nextInt());

        boolean resultado = dao.eliminarPermisos(miPermiso);

        if (resultado) {
            System.out.println("El permiso se eliminó correctamente");
        } else {
            System.out.println("El permiso no se pudo eliminar");
        }
    }
}