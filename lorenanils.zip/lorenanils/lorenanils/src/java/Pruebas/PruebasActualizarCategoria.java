/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebasActualizarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Categoria miCategoria = new Categoria();
        CategoriaDAO DAO = new CategoriaDAO();

        System.out.print("Ingrese el ID de la categoria que desea actualizar: ");
        miCategoria.setIdCategoria(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese la nueva descripcion: ");
        miCategoria.setDescripcion(sc.nextLine());

        boolean resultado = DAO.actualizarCategoria(miCategoria);

        if (resultado) {
            System.out.println("Categoria actualizada correctamente");
        } else {
            System.out.println("No se pudo actualizar la categoria");
        }
    }
}