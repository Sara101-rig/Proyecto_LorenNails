/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner; // 1. Importar la clase Scanner

public class PruebaConsultarPermiso {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // 2. Crear el objeto Scanner
        PermisoDAO permisoDAO = new PermisoDAO();

        // 3. Pedir el ID por consola con un salto de línea (println)
        System.out.println("Por favor ingrese el ID del permiso a consultar:");
        int idPermiso = sc.nextInt();
        sc.nextLine(); // Limpiar el buffer

        Permiso miPermiso = permisoDAO.consultarPermiso(idPermiso);

        if (miPermiso != null) {
            System.out.println("ID Permiso: " + miPermiso.getIdPermiso());
            System.out.println("Nombre: " + miPermiso.getNombre());
            System.out.println("Descripción: " + miPermiso.getDescripcion());

        } else {
            System.out.println("No se encontró el permiso.");
        }
    }
}