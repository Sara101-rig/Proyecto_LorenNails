/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaEliminarRol {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Rol miRol = new Rol();
        RolDAO dao = new RolDAO();

        System.out.println("Por favor ingresar su ID a eliminar");
        miRol.setIdRol(sc.nextInt());

        boolean resultado = dao.eliminarRol(miRol);

        if (resultado) {
            System.out.println("El rol se eliminó correctamente");
        } else {
            System.out.println("El rol no se pudo eliminar");
        }
    }
}