/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaInsertarPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Permiso miPermiso = new Permiso();
        PermisoDAO dao = new PermisoDAO();

        System.out.println("Por favor ingrese el nombre del permiso:");
        miPermiso.setNombre(sc.nextLine());

        System.out.println("Por favor ingrese la descripción del permiso:");
        miPermiso.setDescripcion(sc.nextLine());

        boolean resultado = dao.insertarPermisos(miPermiso);

        if (resultado) {
            System.out.println("Permiso se guardó correctamente");

        } else {
            System.out.println("Permiso no se pudo guardar correctamente");
        }
    }
}