/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaInsertarRol {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Rol miRol = new Rol();
        RolDAO dao = new RolDAO();

        System.out.println("Por favor ingrese el nombre del rol:");
        miRol.setNombre(sc.nextLine());

        System.out.println("Por favor ingrese la descripción del rol:");
        miRol.setDescripcion(sc.nextLine());

        boolean resultado = dao.insertarRol(miRol);

        if (resultado) {
            System.out.println("Rol se guardó correctamente");

        } else {
            System.out.println("Rol no se pudo guardar correctamente");
        }
    }
}