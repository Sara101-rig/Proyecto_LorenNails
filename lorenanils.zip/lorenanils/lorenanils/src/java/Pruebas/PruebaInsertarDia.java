/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.DiaDAO;
import Modelo.Dia;
import java.util.Scanner;

public class PruebaInsertarDia {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Dia miDia = new Dia();
        DiaDAO dao = new DiaDAO();

        System.out.println("Por favor ingrese el nombre del día:");
        miDia.setNombreDia(sc.nextLine());

        boolean resultado = dao.insertarDias(miDia);

        if (resultado) {
            System.out.println("Día se guardó correctamente");

        } else {
            System.out.println("Día no se pudo guardar correctamente");
        }
    }
}