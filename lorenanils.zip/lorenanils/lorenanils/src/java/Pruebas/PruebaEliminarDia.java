/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.DiaDAO;
import Modelo.Dia;
import java.util.Scanner;

public class PruebaEliminarDia {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Dia miDia = new Dia();
        DiaDAO dao = new DiaDAO();

        System.out.println("Por favor ingresar su ID a eliminar");
        miDia.setIdDias(sc.nextInt());

        boolean resultado = dao.eliminarDias(miDia);

        if (resultado) {
            System.out.println("El día se eliminó correctamente");
        } else {
            System.out.println("El día no se pudo eliminar");
        }
    }
}