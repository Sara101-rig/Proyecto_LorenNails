/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CatalogoDAO;
import Modelo.Catalogo;
import java.util.Scanner;

public class PruebasConsultarCatalogo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        CatalogoDAO DAO = new CatalogoDAO();

        System.out.print("Ingrese el ID del catalogo que desea consultar: ");
        int idCatalogo = sc.nextInt();

        Catalogo miCatalogo = DAO.consultarCatalogo(idCatalogo);

        if (miCatalogo != null) {

            System.out.println("Catalogo encontrado");
            System.out.println("ID: "
                    + miCatalogo.getIdCatalogo());
            System.out.println("Descripcion: "
                    + miCatalogo.getDescripcion());
            System.out.println("Imagen: "
                    + miCatalogo.getImagen());
            System.out.println("ID Categoria: "
                    + miCatalogo.getCategoriaIdCategoria());

        } else {

            System.out.println("No se encontro el catalogo");
        }
    }
}