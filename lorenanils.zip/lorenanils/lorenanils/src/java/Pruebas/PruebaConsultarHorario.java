package Pruebas;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.util.Scanner; 

public class PruebaConsultarHorario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); 
        HorarioDAO horarioDAO = new HorarioDAO();

    
        System.out.println("Por favor ingrese el ID del horario a consultar:");
        int idHorarios = sc.nextInt();

        Horario miHorario = horarioDAO.consultarHorario(idHorarios);

        if (miHorario != null) {
            System.out.println("ID Horario: " + miHorario.getIdHorarios());
            System.out.println("Hora de inicio: " + miHorario.getHoraInicio());
            System.out.println("Hora de fin: " + miHorario.getHoraFin());
            System.out.println("Disponibilidad: " + miHorario.getDisponibilidad());

        } else {
            System.out.println("No se encontró el horario.");
        }
    }
}