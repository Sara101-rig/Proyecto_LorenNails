package Pruebas;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.sql.Time;
import java.util.Scanner;

public class PruebaActualizarHorario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Horario miHorario = new Horario();
        HorarioDAO dao = new HorarioDAO();

        System.out.println("Por favor ingresar su ID de horario para actualizar:");
        miHorario.setIdHorarios(sc.nextInt());
        sc.nextLine(); // Limpiar el buffer

        System.out.print("Por favor ingrese la hora de inicio (ej: 08:00:00): ");
        miHorario.setHoraInicio(Time.valueOf(sc.nextLine()));

        System.out.print("Por favor ingrese la hora de fin (ej: 12:00:00): ");
        miHorario.setHoraFin(Time.valueOf(sc.nextLine()));

        System.out.print("Por favor ingrese la disponibilidad: ");
        miHorario.setDisponibilidad(sc.nextLine());

        // ¡ESTO ES LO QUE FALTABA! Pedir el ID del día que SÍ exista en tu BD (ej: 1 o 2)
        System.out.print("Por favor ingrese el ID del día asociado (ej: 1 o 2): ");
        miHorario.setDiaIdDias(sc.nextInt());
        sc.nextLine(); // Limpiar el buffer

        boolean resultado = dao.actualizarHorario(miHorario);

        if (resultado) {
            System.out.println("La actualización se guardó correctamente");
        } else {
            System.out.println("Error al actualizar el horario");
        }
    }
}