/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UbicacionDAO;
import Modelo.Ubicacion;
import java.util.Scanner;

public class PruebasActualizarUbicacion {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Ubicacion miUbicacion = new Ubicacion();
        UbicacionDAO DAO = new UbicacionDAO();

        System.out.print("Ingrese el ID de la ubicacion que desea actualizar: ");
        miUbicacion.setIdUbicacion(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese la nueva direccion: ");
        miUbicacion.setDireccion(sc.nextLine());

        System.out.print("Ingrese la nueva referencia: ");
        miUbicacion.setReferencia(sc.nextLine());

        System.out.print("Ingrese el nuevo ID del usuario: ");
        miUbicacion.setUsuarioIdUsuario(sc.nextInt());

        boolean resultado = DAO.actualizarUbicacion(miUbicacion);

        if (resultado) {
            System.out.println("Ubicacion actualizada correctamente");
        } else {
            System.out.println("No se pudo actualizar la ubicacion");
        }
    }
}