/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.util.Scanner;

public class PruebaEliminarHorario {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Horario miHorario = new Horario();
        HorarioDAO dao = new HorarioDAO();

        System.out.println("Por favor ingresar su ID a eliminar");
        miHorario.setIdHorarios(sc.nextInt());

        boolean resultado = dao.eliminarHorario(miHorario.getIdHorarios());

        if (resultado) {
            System.out.println("El horario se eliminó correctamente");
        } else {
            System.out.println("El horario no se pudo eliminar");
        }
    }
}