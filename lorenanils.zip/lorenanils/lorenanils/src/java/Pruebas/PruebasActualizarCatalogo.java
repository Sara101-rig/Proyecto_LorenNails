/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CatalogoDAO;
import Modelo.Catalogo;
import java.util.Scanner;

public class PruebasActualizarCatalogo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Catalogo miCatalogo = new Catalogo();
        CatalogoDAO DAO = new CatalogoDAO();

        System.out.print("Ingrese el ID del catalogo que desea actualizar: ");
        miCatalogo.setIdCatalogo(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese la nueva descripcion: ");
        miCatalogo.setDescripcion(sc.nextLine());

        System.out.print("Ingrese la nueva imagen: ");
        miCatalogo.setImagen(sc.nextLine());

        System.out.print("Ingrese el nuevo ID de la categoria: ");
        miCatalogo.setCategoriaIdCategoria(sc.nextInt());

        boolean resultado = DAO.actualizarCatalogo(miCatalogo);

        if (resultado) {
            System.out.println("Catalogo actualizado correctamente");
        } else {
            System.out.println("No se pudo actualizar el catalogo");
        }
    }
}