/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.ServicioDAO;
import Modelo.Servicio;
import java.util.Scanner;

public class PruebaEliminarServicio {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Servicio miServicio = new Servicio();
        ServicioDAO DAO = new ServicioDAO();

        System.out.print("Ingrese el ID del servicio que desea eliminar: ");
        miServicio.setIdServicio(sc.nextInt());

        boolean resultado = DAO.eliminarServicio(miServicio);

        if (resultado) {
            System.out.println("Servicio eliminado correctamente");
        } else {
            System.out.println("No se pudo eliminar el servicio");
        }
    }
}
