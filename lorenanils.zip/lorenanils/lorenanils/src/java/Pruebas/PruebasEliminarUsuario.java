/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebasEliminarUsuario {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario miUsuario = new Usuario();
        UsuarioDAO DAO = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario que desea eliminar: ");
        miUsuario.setIdUsuario(sc.nextInt());

        boolean resultado = DAO.eliminarUsuario(miUsuario);

        if (resultado) {

            System.out.println("Usuario eliminado correctamente");

        } else {

            System.out.println("No se pudo eliminar el usuario");
        }
    }
}