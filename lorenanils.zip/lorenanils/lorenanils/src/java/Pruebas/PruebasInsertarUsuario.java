package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;
import java.sql.Date;

public class PruebasInsertarUsuario {

    public static void main (String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario miUsuario = new Usuario();
        UsuarioDAO DAO = new UsuarioDAO();

        System.out.print("Ingrese el nombre: ");
        miUsuario.setNombre(sc.nextLine());

        System.out.print("Ingrese el apellido: ");
        miUsuario.setApellido(sc.nextLine());

        System.out.print("Ingrese el numero de identidad: ");
        miUsuario.setNumeroIdentidad(sc.nextLine());

        System.out.print("Ingrese la fecha de nacimiento (AAAA-MM-DD): ");
        miUsuario.setFechaNacimiento(Date.valueOf(sc.nextLine()));

        System.out.print("Ingrese el correo: ");
        miUsuario.setCorreo(sc.nextLine());

        System.out.print("Ingrese el telefono: ");
        miUsuario.setTelefono(sc.nextLine());

        System.out.print("Ingrese la direccion: ");
        miUsuario.setDireccion(sc.nextLine());

        System.out.print("Ingrese el ID del tipo de documento: ");
        miUsuario.setTipoDocumentoIdTipoDocumento(Integer.parseInt(sc.nextLine()));

        System.out.print("Ingrese el ID del rol: ");
        miUsuario.setIdRol(Integer.parseInt(sc.nextLine()));

        // ¡Agregado! Capturar la contraseña por consola
        System.out.print("Ingrese la contraseña: ");
        miUsuario.setContrasena(sc.nextLine());

        miUsuario.setEstado(1);

        boolean resultado = DAO.insertarUsuario(miUsuario);

        if (resultado) {
            System.out.println("Usuario insertado correctamente");
        } else {
            System.out.println("No se pudo insertar el usuario");
        }
    }
}