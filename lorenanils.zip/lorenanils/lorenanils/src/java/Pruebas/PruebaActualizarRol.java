/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java
 */
package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaActualizarRol {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Rol miRol = new Rol();
        RolDAO dao = new RolDAO();

        System.out.println("Por favor ingresar su ID para actualizar");
        miRol.setIdRol(sc.nextInt());
        sc.nextLine();

        System.out.print("Por favor ingrese el nombre del rol: ");
        miRol.setNombre(sc.nextLine());

        System.out.print("Por favor ingrese la descripción del rol: ");
        miRol.setDescripcion(sc.nextLine());

        boolean resultado = dao.actualizarRol(miRol);

        if (resultado) {
            System.out.println("La actualización se guardó correctamente");
        } else {
            System.out.println("La actualización no se pudo guardar correctamente");
        }
    }
}