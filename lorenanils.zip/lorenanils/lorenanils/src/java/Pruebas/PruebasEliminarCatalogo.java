/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CatalogoDAO;
import Modelo.Catalogo;
import java.util.Scanner;

public class PruebasEliminarCatalogo {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Catalogo miCatalogo = new Catalogo();
        CatalogoDAO DAO = new CatalogoDAO();

        System.out.print("Ingrese el ID del catalogo que desea eliminar: ");
        miCatalogo.setIdCatalogo(sc.nextInt());

        boolean resultado = DAO.eliminarCatalogo(miCatalogo);

        if (resultado) {
            System.out.println("Catalogo eliminado correctamente");
        } else {
            System.out.println("No se pudo eliminar el catalogo");
        }
    }
}