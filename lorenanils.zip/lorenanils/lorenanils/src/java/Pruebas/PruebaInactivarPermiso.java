/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.PermisoDAO;
import Modelo.Permiso;
import java.util.Scanner;

public class PruebaInactivarPermiso {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Permiso miPermiso = new Permiso();
        PermisoDAO dao = new PermisoDAO();

        System.out.println("Por favor ingresar su ID a inactivar");
        miPermiso.setIdPermiso(sc.nextInt());
        sc.nextLine();

        boolean resultado = dao.inactivarPermisos(miPermiso);

        if (resultado) {
            System.out.println("La inactivación se guardó correctamente");

        } else {
            System.out.println("La inactivación no se pudo guardar correctamente");
        }
    }
}