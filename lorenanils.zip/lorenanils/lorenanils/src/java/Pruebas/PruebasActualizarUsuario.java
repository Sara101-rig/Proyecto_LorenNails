/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;
import java.sql.Date;

public class PruebasActualizarUsuario {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Usuario miUsuario = new Usuario();
        UsuarioDAO DAO = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario que desea actualizar: ");
        miUsuario.setIdUsuario(sc.nextInt());
        sc.nextLine();

        System.out.print("Ingrese el nuevo nombre: ");
        miUsuario.setNombre(sc.nextLine());

        System.out.print("Ingrese el nuevo apellido: ");
        miUsuario.setApellido(sc.nextLine());

        System.out.print("Ingrese el nuevo numero de identidad: ");
        miUsuario.setNumeroIdentidad(sc.nextLine());

        System.out.print("Ingrese la nueva fecha de nacimiento (AAAA-MM-DD): ");
        miUsuario.setFechaNacimiento(Date.valueOf(sc.nextLine()));

        System.out.print("Ingrese el nuevo correo: ");
        miUsuario.setCorreo(sc.nextLine());

        System.out.print("Ingrese el nuevo telefono: ");
        miUsuario.setTelefono(sc.nextLine());

        System.out.print("Ingrese la nueva direccion: ");
        miUsuario.setDireccion(sc.nextLine());

        System.out.print("Ingrese el tipo de documento: ");
        miUsuario.setTipoDocumentoIdTipoDocumento(sc.nextInt());

        System.out.print("Ingrese el ID del rol: ");
        miUsuario.setIdRol(sc.nextInt());

        boolean resultado = DAO.actualizarUsuario(miUsuario);

        if (resultado) {

            System.out.println("Usuario actualizado correctamente");

        } else {

            System.out.println("No se pudo actualizar el usuario");
        }
    }
}