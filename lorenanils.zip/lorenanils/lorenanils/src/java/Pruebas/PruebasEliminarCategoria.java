/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebasEliminarCategoria {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Categoria miCategoria = new Categoria();
        CategoriaDAO DAO = new CategoriaDAO();

        System.out.print("Ingrese el ID de la categoria que desea eliminar: ");
        miCategoria.setIdCategoria(sc.nextInt());

        boolean resultado = DAO.eliminarCategoria(miCategoria);

        if (resultado) {
            System.out.println("Categoria eliminada correctamente");
        } else {
            System.out.println("No se pudo eliminar la categoria");
        }
    }
}