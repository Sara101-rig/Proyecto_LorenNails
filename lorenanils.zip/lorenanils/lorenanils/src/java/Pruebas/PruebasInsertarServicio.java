/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.ServicioDAO;
import Modelo.Servicio;
import java.util.Scanner;

public class PruebasInsertarServicio {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Servicio miServicio = new Servicio();
        ServicioDAO DAO = new ServicioDAO();

        System.out.print("Ingrese el nombre del servicio: ");
        miServicio.setNombre(sc.nextLine());

        System.out.print("Ingrese la descripcion del servicio: ");
        miServicio.setDescripcion(sc.nextLine());

        System.out.print("Ingrese el precio del servicio: ");
        miServicio.setPrecio(sc.nextBigDecimal());

        System.out.print("Ingrese el ID del catalogo: ");
        miServicio.setCatalogoidCatalogo(sc.nextInt());

        boolean resultado = DAO.insertarServicio(miServicio);

        if (resultado) {
            System.out.println("Servicio insertado correctamente");
        } else {
            System.out.println("No se pudo insertar el servicio");
        }
    }
} 