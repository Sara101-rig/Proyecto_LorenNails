/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servlet;

import Controlador.ServicioDAO;
import Modelo.Servicio;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ServicioServlet", urlPatterns = {"/ServicioServlet"})
public class ServicioServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Prueba ServicioServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Prueba de conexión con ServicioDAO</h1>");
            
            String idParam = request.getParameter("id");
            
            if (idParam != null && !idParam.isEmpty()) {
                int idPrueba = Integer.parseInt(idParam);
                
                
                ServicioDAO dao = new ServicioDAO();
                Servicio ser = dao.consultarServicio(idPrueba);
                
                if (ser != null) {
                    out.println("<p style='color:green;'>¡Servicio encontrado con éxito!</p>");
                    
                    out.println("<p><b>ID Servicio:</b> " + ser.getIdServicio() + "</p>");
                    out.println("<p><b>Nombre:</b> " + ser.getNombre() + "</p>");
                } else {
                    out.println("<p style='color:red;'>No se encontró ningún Servicio con el ID " + idPrueba + ".</p>");
                }
            } else {
                out.println("<p style='color:orange;'>Por favor, ingresa un ID en la URL.</p>");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}



 


