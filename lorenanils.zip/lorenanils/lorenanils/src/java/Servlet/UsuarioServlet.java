package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "UsuarioServlet", urlPatterns = {"/UsuarioServlet"})
public class UsuarioServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario miUsuario = usuarioDAO.consultarUsuarioPorCorreo(correo); 

        if (miUsuario != null && miUsuario.getContrasena().equals(contrasena)) {
            
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogueado", miUsuario);
            
           
            response.sendRedirect(request.getContextPath() + "/dashboard.jsp"); 
        } else {
            
            response.sendRedirect(request.getContextPath() + "/index.jsp?error=credenciales_incorrectas");
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}