package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("contrasena");

        UsuarioDAO usuarioDAO = new UsuarioDAO();

       boolean accesoValido = usuarioDAO.validarLogin(correo, contrasena);

        if (accesoValido) {
            HttpSession session = request.getSession();
            
            
            session.setAttribute("correoUsuario", correo);
            
            // 2. Obtenemos el objeto usuario completo desde la BD usando tu DAO para extraer su nombre
            Usuario usuarioObj = usuarioDAO.obtenerUsuarioPorCorreo(correo); // (
            if (usuarioObj != null) {
                session.setAttribute("nombreUsuario", usuarioObj.getNombre()); // O .getNombres() según cómo se llame en tu modelo
            }
            
            response.sendRedirect(request.getContextPath() + "/vista/catalogo.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        response.sendRedirect(request.getContextPath() + "/vista/login.jsp");
    }
}