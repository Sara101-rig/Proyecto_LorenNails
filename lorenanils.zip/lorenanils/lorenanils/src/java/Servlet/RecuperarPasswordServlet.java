package Servlet;

import Modelo.Usuario;
import Controlador.UsuarioDAO;

import java.io.IOException;
import java.util.Properties;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

@WebServlet(name = "RecuperarPasswordServlet", urlPatterns = {"/RecuperarPasswordServlet"})
public class RecuperarPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String correoDestino = request.getParameter("correo");
        
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuarioEncontrado = usuarioDAO.consultarUsuarioPorCorreo(correoDestino);
        
        if (usuarioEncontrado != null) {
            
            boolean enviado = enviarCorreoRecuperacion(correoDestino, usuarioEncontrado.getNombre());
            
            if (enviado) {
                response.sendRedirect(request.getContextPath() + "/vista/login.jsp?mensaje=enviado");
            } else {
                response.sendRedirect(request.getContextPath() + "/vista/recuperar.jsp?error=errorcorreo");
            }
            
        } else {
            response.sendRedirect(request.getContextPath() + "/vista/recuperar.jsp?error=noencontrado");
        }
    }

    private boolean enviarCorreoRecuperacion(String destinatario, String nombreUsuario) {
        
        final String remitente = "lorendiaz3412@gmail.com"; 
        final String passwordApp = "jung dzhf nnsj nqst";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");  
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");          

        // Configuración para omitir la validación estricta de certificados en entornos locales
        try {
            javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
                (hostname, session) -> true
            );
            javax.net.ssl.SSLContext context = javax.net.ssl.SSLContext.getInstance("TLS");
            context.init(null, new javax.net.ssl.TrustManager[]{
                new javax.net.ssl.X509TrustManager() {
                    @Override
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() { 
                        return null; 
                    }
                    @Override
                    public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        // Confiabilidad por defecto para el cliente
                    }
                    @Override
                    public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        // Confiabilidad por defecto para el servidor SMTP de Google
                    }
                }
            }, new java.security.SecureRandom());
            javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Crear la sesión con autenticación
        Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, passwordApp);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente, "Loren Nails Soporte"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("Recuperación de Contraseña - Loren Nails");
            
            String contenidoHtml = "<h3>¡Hola, " + nombreUsuario + "!</h3>"
                    + "<p>Has solicitado restablecer tu contraseña en <b>Loren Nails</b>.</p>"
                    + "<p>Haz clic en el siguiente enlace para crear una nueva contraseña:</p>"
                    + "<a href='http://localhost:8080/lorenanils/vista/nuevo-password.jsp'>Restablecer Contraseña</a>"
                    + "<p>Si tú no solicitaste esto, puedes ignorar este mensaje.</p>";
            
            message.setContent(contenidoHtml, "text/html; charset=utf-8");

            Transport.send(message);
            return true;

        } catch (MessagingException e) {
            System.out.println("--- ERROR DE MENSAJERÍA SMTP ---");
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.out.println("--- ERROR GENERAL ---");
            e.printStackTrace();
            return false;
        }
    }
}