package Servlet;

import Controlador.UbicacionDAO;
import Modelo.Ubicacion;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "UbicacionServlet", urlPatterns = {"/UbicacionServlet"})
public class UbicacionServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Prueba UbicacionServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Prueba de conexión con UbicacionDAO</h1>");
            
            String idParam = request.getParameter("id");
            
            if (idParam != null && !idParam.isEmpty()) {
                int idPrueba = Integer.parseInt(idParam);
                
                UbicacionDAO dao = new UbicacionDAO();
                Ubicacion ubicacion = dao.consultarUbicacion(idPrueba);
                
                if (ubicacion != null) {
                    out.println("<p style='color:green;'>¡Ubicación encontrada con éxito!</p>");
                    out.println("<p><b>ID:</b> " + ubicacion.getIdUbicacion() + "</p>");
                    out.println("<p><b>Nombre:</b> " + ubicacion.getNombre() + "</p>");
                } else {
                    out.println("<p style='color:red;'>No se encontró ninguna ubicación con el ID " + idPrueba + ".</p>");
                }
            } else {
                out.println("<p style='color:orange;'>Por favor, ingresa un ID en la URL (Ejemplo: ?id=1).</p>");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
