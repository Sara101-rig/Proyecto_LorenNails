/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlet;

import Controlador.DiaDAO;
import Modelo.Dia;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DiaServlet", urlPatterns = {"/DiaServlet"})
public class DiaServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Prueba DiaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Prueba de conexión con DiaDAO</h1>");
           
            String idParam = request.getParameter("id");
           
            if (idParam != null && !idParam.isEmpty()) {
                int idPrueba = Integer.parseInt(idParam);
               
                DiaDAO dao = new DiaDAO();
                Dia cat = dao.consultarDias(idPrueba);
               
                if (cat != null) {
                    out.println("<p style='color:green;'>!Día encontrado con éxito!</p>");
                   
                    out.println("<p><b>ID Día:</b> " + cat.getIdDias() + "</p>");
                    out.println("<p><b>Nombre Día:</b> " + cat.getNombreDia() + "</p>");
                   
                } else {
                    out.println("<p style='color:red;'>No se encontró ningún día con ese ID.</p>");
                }

            } else {
                out.println("<p style='color:orange;'>Por favor ingrese un ID en la URL.</p>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
