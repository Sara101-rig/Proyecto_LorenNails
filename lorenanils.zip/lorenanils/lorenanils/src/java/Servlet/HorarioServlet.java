/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlet;

import Controlador.HorarioDAO;
import Modelo.Horario;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "HorarioServlet", urlPatterns = {"/HorarioServlet"})
public class HorarioServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        int idHorarios = Integer.parseInt(request.getParameter("id"));
        
        HorarioDAO horarioDAO = new HorarioDAO();
        Horario miHorario = horarioDAO.consultarHorario(idHorarios);

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Prueba HorarioServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Prueba de conexión con HorarioDAO</h1>");
            
            if (miHorario != null) {
                out.println("<p style='color:green;'>¡Horario encontrado con éxito!</p>");
                out.println("<p><b>ID Horario:</b> " + miHorario.getIdHorarios() + "</p>");
                out.println("<p><b>Hora Inicio:</b> " + miHorario.getHoraInicio() + "</p>");
                out.println("<p><b>Hora Fin:</b> " + miHorario.getHoraFin() + "</p>");
                out.println("<p><b>Disponibilidad:</b> " + miHorario.getDisponibilidad() + "</p>");
                out.println("<p><b>ID Día:</b> " + miHorario.getDiaIdDias() + "</p>");
            } else {
                out.println("<p style='color:red;'>No se encontró el horario con el ID especificado.</p>");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}