package servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "ListarCitasServlet", urlPatterns = {"/ListarCitasServlet"})
public class ListarCitasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String correoUsuario = (String) session.getAttribute("correoUsuario");
        
        if (correoUsuario == null) {
            response.sendRedirect(request.getContextPath() + "/vista/login.jsp");
            return;
        }
        
        request.getRequestDispatcher("/vista/citas.jsp").forward(request, response);
    }
}