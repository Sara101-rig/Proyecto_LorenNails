package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import java.sql.Date;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "RegistroServlet", urlPatterns = {"/RegistroServlet"})
public class RegistroServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try {
            // 1. Capturar los datos enviados desde el formulario JSP
            String nombre = request.getParameter("nombre");
            String apellido = request.getParameter("apellido");
            String tipoDocStr = request.getParameter("tipo_documento");
            String numeroIdentidad = request.getParameter("documento");
            String fechaNacStr = request.getParameter("fechaNacimiento");
            String telefono = request.getParameter("telefono");
            String correo = request.getParameter("correo");
            String direccion = request.getParameter("direccion");
            String contrasena = request.getParameter("contrasena");

            // 2. Convertir los tipos de datos necesarios
            int tipoDocumento = Integer.parseInt(tipoDocStr);
            Date fechaNacimiento = Date.valueOf(fechaNacStr);

            // 3. Crear el objeto Usuario y asignar valores
            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombre(nombre);
            nuevoUsuario.setApellido(apellido);
            nuevoUsuario.setTipoDocumentoIdTipoDocumento(tipoDocumento);
            nuevoUsuario.setNumeroIdentidad(numeroIdentidad);
            nuevoUsuario.setFechaNacimiento(fechaNacimiento);
            nuevoUsuario.setTelefono(telefono);
            nuevoUsuario.setCorreo(correo);
            nuevoUsuario.setDireccion(direccion);
            nuevoUsuario.setContrasena(contrasena);
            
            // Asignar rol de cliente (2) y estado activo (1) por defecto
            nuevoUsuario.setIdRol(2); 
            nuevoUsuario.setEstado(1);

            // 4. Guardar usando el DAO
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            boolean registrado = usuarioDAO.insertarUsuario(nuevoUsuario);

            if (registrado) {
    
    response.sendRedirect(request.getContextPath() + "/vista/login.jsp");
} else {
    response.sendRedirect(request.getContextPath() + "/vista/registro.jsp?error=falloregistro");
}

        } catch (Exception e) {
            // Esto imprimirá el error exacto en la consola de NetBeans si algo falla
            System.out.println("--- ERROR EN EL SERVLET DE REGISTRO ---");
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/index.jsp?error=excepcion");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}