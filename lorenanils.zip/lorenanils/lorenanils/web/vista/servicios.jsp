<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuestros Servicios - Loren Nails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/servicios.css">
</head>
<body>


    <header class="navbar">
        <a href="${pageContext.request.contextPath}/index.jsp" class="brand-logo">
            <span class="brand-badge">LN⁺</span>
            <span>LOREN NAILS</span>
        </a>
        <nav class="nav-links">
            <a href="${pageContext.request.contextPath}/index.jsp">Inicio</a>
            <a href="${pageContext.request.contextPath}/vista/servicios.jsp" class="active">Nuestros Servicios</a>
            <a href="${pageContext.request.contextPath}/vista/cuidados.jsp">Cuidados</a>
            <a href="${pageContext.request.contextPath}/vista/login.jsp" class="btn-login-secondary">Iniciar Sesión</a>
        </nav>
    </header>

    
    <main class="services-container" style="max-width: 1400px; margin: 0 auto; padding: 3.5rem 1.5rem;">
        
        <section class="services-header">
            <span class="sub-heading">EXPERIENCIA Y ELEGANCIA ✨</span>
            <h1>Nuestros Servicios</h1>
            <p>Elige el procedimiento ideal para resaltar tus manos y pies con las mejores técnicas y acabados profesionales.</p>
        </section>


        <section class="services-grid" style="display: flex; flex-wrap: wrap; justify-content: center; gap: 1.5rem; margin-bottom: 4rem;">
            

            
            
           
            <article class="service-card">
                <div class="service-icon">💅</div>
                <h2>Manicura Convencional</h2>
                <p>Cuidado completo con limpieza de cutícula, limado, arreglo y esmalte tradicional para un acabado impecable.</p>
                <div class="service-price">$ 20.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 60 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

          
            <article class="service-card">
                <div class="service-icon">🟣</div>
                <h2>Manicura Semipermanente</h2>
                <p>Esmaltado de alta duración con curado LED, limpieza profunda de cutícula, nivelación y brillo superior.</p>
                <div class="service-price">$ 47.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 1h 20 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

        
            <article class="service-card">
                <div class="service-icon">✨</div>
                <h2>Base Rubber</h2>
                <p>Refuerzo para uñas frágiles que aporta alineación, volumen y máxima resistencia frente a impactos.</p>
                <div class="service-price">$ 60.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 1h 30 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>
                
            
            <article class="service-card">
                <div class="service-icon">🍃</div>
                <h2>Dipping System</h2>
                <p>Técnica de inmersión en polvo acrílico enriquecido con vitaminas, aporta dureza.</p>
                <div class="service-price">$ 70.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 1h 15 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

        
            <article class="service-card">
                <div class="service-icon">💎</div>
                <h2>Acrílico & Polygel</h2>
                <p>Extensión y esculpido en la forma y largo que elijas, con acabado natural y resistente.</p>
                <div class="service-price">$ 90.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 2h 00 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

      
            <article class="service-card">
                <div class="service-icon">🌸</div>
                <h2>Sistema Soft Gel</h2>
                <p>Uñas de gel suave adheridas con base especial para una aplicación rápida, sin daño y de fácil retiro.</p>
                <div class="service-price">$ 65.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 1h 10 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

           
            <article class="service-card">
                <div class="service-icon">🦶</div>
                <h2>Pedicura Especializada</h2>
                <p>Limpieza de canales, exfoliación, hidratación profunda con masajes y esmaltado semipermanente o convencional.</p>
                <div class="service-price">Convencional $ 25.000</div> <br>
                <div class="service-price">Semipermanente $ 55.000</div> <br>
                <div class="service-footer">
                    <span class="service-detail">⏱️ 1h 30 min</span>
                    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-card">Agendar Cita</a>
                </div>
            </article>

        </section>

        
        <section class="info-banner">
            <div class="info-text">
                <h3>¿No sabes qué servicio elegir?</h3>
                <p>Te ayudamos a encontrar el tratamiento ideal según el estado y la longitud de tus uñas.</p>
            </div>
            <a href="${pageContext.request.contextPath}/vista/cuidados.jsp" class="btn-secondary-banner">Ver Cuidados →</a>
        </section>

    </main>

</body>
</html>