<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    String correoValidacion = (String) session.getAttribute("correoUsuario");
    if (correoValidacion == null) {
        response.sendRedirect(request.getContextPath() + "/vista/login.jsp");
        return; 
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agendar Cita - Loren Nails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/agenda.css">
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <div class="logo-badge">
                <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C12 2 8 6 8 10.5C8 13 9.8 15 12 15C14.2 15 16 13 16 10.5C16 6 12 2 12 2Z" fill="white"/></svg>
            </div>
            <div class="logo-text">LOREN<span>NAILS</span></div>
        </div>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/index.jsp">Inicio</a>
            <a href="${pageContext.request.contextPath}/vista/servicios.jsp">Servicios</a>
            <a href="${pageContext.request.contextPath}/vista/catalogo.jsp" class="active">Catálogo</a>
            <a href="${pageContext.request.contextPath}/vista/nosotros.jsp">Nosotros</a>
            <a href="${pageContext.request.contextPath}/vista/contacto.jsp">Contacto</a>
        </div>
        <div class="nav-actions">
            <% 
                String correoUsuario = (String) session.getAttribute("correoUsuario");
                if (correoUsuario != null) {
            %>
                <span class="user-greeting">Hola, <%= correoUsuario %></span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-outline">Cerrar sesión</a>
            <% 
                } else { 
            %>
                <a href="${pageContext.request.contextPath}/vista/login.jsp" class="btn-outline">Iniciar sesión</a>
            <% 
                } 
            %>
        </div>
    </nav>
 
    <header class="booking-header">
        <h1>Agendar tu Cita</h1>
        <p>Elige el servicio que deseas, la fecha y hora que prefieras.<br>¡Déjanos consentirte!</p>
    </header>

    <div class="steps-container">
        <div class="step-card active">
            <div class="step-number">1</div>
            <div class="step-info">
                <span class="step-title">Servicio</span>
                <span class="step-desc">Elige tu servicio</span>
            </div>
        </div>
        <div class="step-line"></div>
        <div class="step-card">
            <div class="step-number">2</div>
            <div class="step-info">
                <span class="step-title">Fecha y hora</span>
                <span class="step-desc">Selecciona cuándo</span>
            </div>
        </div>
        <div class="step-line"></div>
        <div class="step-card">
            <div class="step-number">3</div>
            <div class="step-info">
                <span class="step-title">Tus datos</span>
                <span class="step-desc">Completa tus datos</span>
            </div>
        </div>
        <div class="step-line"></div>
        <div class="step-card">
            <div class="step-number">4</div>
            <div class="step-info">
                <span class="step-title">Confirmación</span>
                <span class="step-desc">Revisa y confirma</span>
            </div>
        </div>
    </div>

    <div class="booking-main-layout">
        
        <div class="booking-content">
            
            <section class="booking-section">
                <h2>Elige el servicio</h2>
                <div class="search-service-box">
                    <input type="text" placeholder="Buscar servicio...">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </div>

                <div class="services-grid">
                    <div class="service-option-card" data-name="Manicure Clásico" data-duration="60 min" data-price="$40.000" data-swatch="swatch-1">
                        <div class="opt-image swatch-1">
                            <span class="badge-pop">★ Popular</span>
                            <button class="btn-heart">♡</button>
                        </div>
                        <div class="opt-body">
                            <h3>Manicure Clásico</h3>
                            <div class="opt-meta">
                                <span>60 min</span>
                                <span class="opt-price">$40.000</span>
                            </div>
                        </div>
                    </div>

                    <div class="service-option-card selected" data-name="Semipermanente" data-duration="90 min" data-price="$65.000" data-swatch="swatch-2">
                        <div class="opt-image swatch-2">
                            <span class="badge-pop">★ Popular</span>
                            <button class="btn-heart">♡</button>
                        </div>
                        <div class="opt-body">
                            <h3>Semipermanente</h3>
                            <div class="opt-meta">
                                <span>90 min</span>
                                <span class="opt-price">$65.000</span>
                            </div>
                        </div>
                    </div>

                    <div class="service-option-card" data-name="Acrílicas" data-duration="120 min" data-price="$90.000" data-swatch="swatch-4">
                        <div class="opt-image swatch-4">
                            <span class="badge-pop">★ Popular</span>
                            <button class="btn-heart">♡</button>
                        </div>
                        <div class="opt-body">
                            <h3>Acrílicas</h3>
                            <div class="opt-meta">
                                <span>120 min</span>
                                <span class="opt-price">$90.000</span>
                            </div>
                        </div>
                    </div>

                    <div class="service-option-card" data-name="Nail Art" data-duration="60 min" data-price="$50.000" data-swatch="swatch-7">
                        <div class="opt-image swatch-7">
                            <span class="badge-pop">★ Popular</span>
                            <button class="btn-heart">♡</button>
                        </div>
                        <div class="opt-body">
                            <h3>Nail Art</h3>
                            <div class="opt-meta">
                                <span>60 min</span>
                                <span class="opt-price">$50.000</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <section class="booking-section">
                <h2>Elige fecha y hora</h2>
                
                <div class="datetime-picker-grid">
                    
                    <div class="calendar-card">
                        <div class="cal-header">
                            <button class="cal-nav">&lt;</button>
                            <span class="cal-month">Junio 2025</span>
                            <button class="cal-nav">&gt;</button>
                        </div>
                        <div class="cal-weekdays">
                            <span>Lun</span><span>Mar</span><span>Mié</span><span>Jue</span><span>Vie</span><span>Sáb</span><span>Dom</span>
                        </div>
                        <div class="cal-grid">
                            <span class="muted">26</span><span class="muted">27</span><span class="muted">28</span><span class="muted">29</span><span class="muted">30</span><span class="muted">31</span><span>1</span>
                            <span>2</span><span>3</span><span>4</span><span>5</span><span>6</span><span>7</span><span>8</span>
                            <span>9</span><span>10</span><span>11</span><span class="selected-day">12</span><span>13</span><span>14</span><span>15</span>
                            <span>16</span><span>17</span><span>18</span><span>19</span><span>20</span><span>21</span><span>22</span>
                            <span>23</span><span>24</span><span>25</span><span>26</span><span>27</span><span>28</span><span>29</span>
                            <span>30</span><span class="muted">1</span><span class="muted">2</span><span class="muted">3</span><span class="muted">4</span><span class="muted">5</span><span class="muted">6</span>
                        </div>
                    </div>

                    <div class="hours-container">
                        <p class="hours-subtitle">Horas disponibles para el <span id="lbl-selected-day-text">12</span> de junio, 2025</p>
                        <div class="hours-grid">
                            <button class="hour-chip">09:00 AM</button>
                            <button class="hour-chip">10:00 AM</button>
                            <button class="hour-chip">11:00 AM</button>
                            <button class="hour-chip">12:00 PM</button>
                            <button class="hour-chip">01:00 PM</button>
                            <button class="hour-chip selected-hour">02:00 PM</button>
                            <button class="hour-chip">03:00 PM</button>
                            <button class="hour-chip">04:00 PM</button>
                            <button class="hour-chip">05:00 PM</button>
                            <button class="hour-chip">06:00 PM</button>
                            <button class="hour-chip">07:00 PM</button>
                            <button class="hour-chip">08:00 PM</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
   
        <div class="booking-summary-card">
            <h3>Resumen de tu cita</h3>
            
            <div id="summary-img" class="summary-preview-img swatch-2"></div>

            <div class="summary-details">
                <div class="sum-row-item">
                    <span class="sum-label">Servicio</span>
                    <span id="sum-service" class="sum-value" style="font-weight:600;">Semipermanente</span>
                </div>
                <div class="sum-row-item">
                    <span class="sum-label">Duración</span>
                    <span id="sum-duration" class="sum-value">90 min</span>
                </div>
                <div class="sum-row-item">
                    <span class="sum-label">Fecha</span>
                    <span id="sum-date" class="sum-value">12 de junio de 2025</span>
                </div>
                <div class="sum-row-item">
                    <span class="sum-label">Hora</span>
                    <span id="sum-hour" class="sum-value">02:00 PM</span>
                </div>
            </div>

            <div class="summary-total-row">
                <span>Total</span>
                <span id="sum-price" class="summary-price">$65.000</span>
            </div>

            <a href="#" class="btn-continue">
                Continuar 
                <svg viewBox="0 0 24 24" fill="none"><path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </a>

            <div class="secure-badge">
                <svg viewBox="0 0 24 24" fill="none"><rect x="3" y="11" width="18" height="11" rx="2" stroke="currentColor" stroke-width="2"/><path d="M7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7V11" stroke="currentColor" stroke-width="2"/></svg>
                Tu información está segura con nosotros.
            </div>
        </div>

    </div>

    <a href="${pageContext.request.contextPath}/ListarCitasServlet" class="floating-cta">
        📅 Mis citas
    </a>

    <!-- VENTANA MODAL FLOTANTE DE CONFIRMACIÓN -->
    <div id="modalConfirmacion" class="confirm-overlay" style="display: none;">
        <div class="confirm-card">
            <div class="confirm-icon" style="width: 56px; height: 56px; border-radius: 50%; background: #fbeaf0; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
                <span style="font-size: 28px; color: #993556;">✓</span>
            </div>
            <h2>Cita confirmada</h2>
            <p class="modal-sub">Te esperamos en la fecha y hora indicadas.</p>
            
            <div class="modal-details" style="text-align: left; margin-top: 15px; border-top: 1px solid #eee; border-bottom: 1px solid #eee; padding: 1rem 0;">
                <div class="modal-row" style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span class="m-label" style="color: #8a8a86; font-size: 13px;">👤 Cliente</span>
                    <span class="m-val" style="font-weight: 600; font-size: 13px;"><%= correoUsuario %></span>
                </div>
                <div class="modal-row" style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span class="m-label" style="color: #8a8a86; font-size: 13px;">📍 Dirección</span>
                    <span class="m-val" style="font-weight: 600; font-size: 13px;">Cra 45 # 12-30, Bogotá</span>
                </div>
                <div class="modal-row" style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span class="m-label" style="color: #8a8a86; font-size: 13px;">✨ Servicio</span>
                    <span id="modal-service" class="m-val" style="font-weight: 600; font-size: 13px;">Semipermanente</span>
                </div>
                <div class="modal-row" style="display: flex; justify-content: space-between;">
                    <span class="m-label" style="color: #8a8a86; font-size: 13px;">📅 Fecha y hora</span>
                    <span id="modal-datetime" class="m-val" style="font-weight: 600; font-size: 13px;">12 de junio de 2025, 02:00 PM</span>
                </div>
            </div>

            <div class="summary-total-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; font-size: 14px; color: #8a8a86;">
                <span>Total</span>
                <span id="modal-price" class="summary-price" style="font-size: 20px; font-weight: 600; color: #993556;">$65.000</span>
            </div>

            <form action="${pageContext.request.contextPath}/CrearCitaServlet" method="POST">
                <input type="hidden" name="servicio" id="input-serv" value="Semipermanente">
                <input type="hidden" name="fecha" id="input-fecha" value="12 de junio de 2025">
                <input type="hidden" name="hora" id="input-hora" value="02:00 PM">
                <input type="hidden" name="total" id="input-total" value="$65.000">
                
                <button type="submit" class="confirm-btn" style="width: 100%; background: #993556; border: none; color: #ffffff; height: 46px; border-radius: 23px; font-size: 14px; font-weight: 600; cursor: pointer;">Listo</button>
            </form>
        </div>
    </div>
 
    <script>
        document.addEventListener("DOMContentLoaded", function () {
        
            const serviceCards = document.querySelectorAll(".service-option-card");
            
            serviceCards.forEach(card => {
                card.addEventListener("click", function () {
                    serviceCards.forEach(c => c.classList.remove("selected"));
                    this.classList.add("selected");

                    const name = this.getAttribute("data-name");
                    const duration = this.getAttribute("data-duration");
                    const price = this.getAttribute("data-price");
                    const swatch = this.getAttribute("data-swatch");

                    document.getElementById("sum-service").textContent = name;
                    document.getElementById("sum-duration").textContent = duration;
                    document.getElementById("sum-price").textContent = price;

                    const summaryImg = document.getElementById("summary-img");
                    summaryImg.className = "summary-preview-img " + swatch;
                });
            });

         
            const calDays = document.querySelectorAll(".cal-grid span:not(.muted)");
            
            calDays.forEach(day => {
                day.addEventListener("click", function () {
                    document.querySelectorAll(".cal-grid span").forEach(d => d.classList.remove("selected-day"));
                    this.classList.add("selected-day");

                    const diaSeleccionado = this.textContent;
                    const fechaCompleta = diaSeleccionado + " de junio de 2025";
                    
                    document.getElementById("sum-date").textContent = fechaCompleta;
                    document.getElementById("lbl-selected-day-text").textContent = diaSeleccionado;
                });
            });

     
            const hourChips = document.querySelectorAll(".hour-chip");
            
            hourChips.forEach(chip => {
                chip.addEventListener("click", function () {
                    hourChips.forEach(h => h.classList.remove("selected-hour"));
                    this.classList.add("selected-hour");

                    const horaSeleccionada = this.textContent;
                    document.getElementById("sum-hour").textContent = horaSeleccionada;
                });
            });

         
            const btnContinue = document.querySelector(".btn-continue");
            const modal = document.getElementById("modalConfirmacion");

            btnContinue.addEventListener("click", function (e) {
                e.preventDefault(); 

               
                const serv = document.getElementById("sum-service").textContent;
                const fec = document.getElementById("sum-date").textContent;
                const hor = document.getElementById("sum-hour").textContent;
                const pri = document.getElementById("sum-price").textContent;

                document.getElementById("modal-service").textContent = serv;
                document.getElementById("modal-datetime").textContent = fec + ", " + hor;
                document.getElementById("modal-price").textContent = pri;

                document.getElementById("input-serv").value = serv;
                document.getElementById("input-fecha").value = fec;
                document.getElementById("input-hora").value = hor;
                document.getElementById("input-total").value = pri;

                
                modal.style.display = "flex";
            });
        });
    </script>
</body>
</html>