<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Línea de Tiempo de Cuidado - Loren Nails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/cuidados.css">
</head>
<body>

  
    <header class="navbar">
        <a href="${pageContext.request.contextPath}/vista/catalogo.jsp" class="brand-logo">
            <span class="brand-badge">LN⁺</span>
            <span>LOREN NAILS</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/vista/catalogo.jsp">Catálogo</a>
            <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-nav">Agendar cita</a>
        </div>
    </header>

   
    <main class="timeline-wrapper">
        
        <section class="intro-header">
            <span class="tag-label">GUÍA DE MANTENIMIENTO 🌸</span>
            <h1>Línea de Tiempo del Cuidado</h1>
            <p>Sigue esta hoja de ruta día a día para que tu manicura o pedicura luzca impecable y tus uñas se mantengan fuertes.</p>
        </section>

    
        <section class="timeline">

     
            <div class="timeline-item">
                <div class="timeline-dot">1</div>
                <div class="timeline-content">
                    <div class="time-badge">Primeras 24 Horas</div>
                    <h2>Fase de Asentamiento y Sellado</h2>
                    <p class="phase-desc">El producto y la piel están ajustándose. Evita someter tus manos o pies a cambios drásticos de temperatura.</p>
                    <ul class="care-tips">
                        <li><span>🚫</span> Evita agua hirviendo, vapores continuos o saunas.</li>
                        <li><span>🧼</span> No utilices químicos fuertes de limpieza sin guantes de goma.</li>
                        <li><span>🖐️</span> No presiones fuertemente la punta de las uñas recién trabajadas.</li>
                    </ul>
                </div>
            </div>

       
            <div class="timeline-item">
                <div class="timeline-dot">2</div>
                <div class="timeline-content">
                    <div class="time-badge">Día 2 al Día 14</div>
                    <h2>Mantenimiento Diario y Protección</h2>
                    <p class="phase-desc">Etapa clave de hidratación para conservar el brillo y prevenir levantamientos o grietas.</p>
                    <ul class="care-tips">
                        <li><span>💧</span> Aplica gotas de aceite de cutícula por las noches en la base de la uña.</li>
                        <li><span>📦</span> No uses tus uñas como herramientas para destapar, raspar o abrir latas.</li>
                        <li><span>🦶</span> En pedicura: aplica crema rica en urea al acostarte para hidratar talones.</li>
                    </ul>
                </div>
            </div>

            <div class="timeline-item">
                <div class="timeline-dot">3</div>
                <div class="timeline-content">
                    <div class="time-badge">Día 15 al Día 21</div>
                    <h2>Evaluación y Tiempo de Retoque</h2>
                    <p class="phase-desc">El crecimiento natural de la uña desplaza el centro de gravedad. Es momento de programar tu cita.</p>
                    <ul class="care-tips">
                        <li><span>📅</span> Revisa si necesitas mantenimiento para equilibrar el peso de la uña.</li>
                        <li><span>⚠️</span> Si hay una filtración o levantamiento, no la muerdas ni la arranques a la fuerza.</li>
                        <li><span>✨</span> Un retoque oportuno previene fisuras y protege tu queratina natural.</li>
                    </ul>
                </div>
            </div>

        </section>


        <section class="pro-tip-card">
            <div class="tip-icon">💡</div>
            <div class="tip-body">
                <h3>¿Necesitas un retiro o retoque profesional?</h3>
                <p>Retirar el acrílico, gel o semipermanente en casa puede adelgazar tus capas de uña natural. Permítenos cuidarte en sala.</p>
            </div>
            <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-action">Agendar Retoque <span>→</span></a>
        </section>

    </main>

</body>
</html>