<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Loren Nails - Inicio</title>


    <!-- =====================================================
         FUENTES
    ====================================================== -->

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,500;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Dancing+Script:wght@600;700&display=swap"
          rel="stylesheet">


    <!-- =====================================================
         CSS
    ====================================================== -->

    <link rel="stylesheet"
          href="<%= request.getContextPath() %>/css/inicio.css">

</head>


<body>


<!-- =========================================================
     NAVBAR
========================================================= -->

<header class="navbar">


    <!-- MENÚ IZQUIERDO -->

    <div class="nav-group">

        <a href="inicio.jsp"
           class="nav-link active">

            Inicio

            <span class="active-dot">✦</span>

        </a>

    </div>



    <!-- LOGO CENTRAL -->

    <a href="inicio.jsp"
       class="brand-logo">

        <img src="../img/logo.png"
             alt="Loren Nails Logo"
             class="logo-img">

    </a>



    <!-- MENÚ DERECHO -->

    <div class="nav-group">

        <a href="conocenos.jsp"
           class="nav-link">

            Conócenos

        </a>


        <a href="login.jsp"
           class="btn-login">

            <span class="user-icon">👤</span>

            Iniciar sesión

        </a>

    </div>

</header>



<!-- =========================================================
     HERO PRINCIPAL
========================================================= -->

<main class="hero-container">


    <!-- CONTENIDO -->

    <div class="hero-content">


        <span class="tagline">

            💅🏻 LOREN NAILS SYSTEM ✨

        </span>



        <h1 class="hero-title">


            <span class="title-main">

                Tu momento

            </span>


            <br>


            <span class="title-cursive">

                para brillar

                <span class="sparkle">

                    ✨

                </span>

            </span>


            <br>


            <span class="title-main">

                comienza aquí

            </span>


        </h1>



        <p class="hero-description">

            Agenda tu cita, elige tu estilo y disfruta una experiencia

            <strong>

                pensada para ti.

            </strong>

            ✨

        </p>



        <!-- BOTONES -->

        <div class="hero-buttons">


            <!-- CATÁLOGO -->

            <a href="catalogo.jsp"
               class="btn-primary">

                <span class="btn-icon">

                    ✨

                </span>

                Catálogo

                <span class="btn-arrow">

                    →

                </span>

            </a>



            <!-- AGENDAR CITA -->

            <a href="agenda.jsp"
               class="btn-secondary">

                <span class="btn-icon">

                    📅

                </span>

                Agenda tu cita

            </a>


        </div>

    </div>



    <!-- =====================================================
         IMAGEN PRINCIPAL
    ====================================================== -->

    <div class="hero-image-wrapper">


        <div class="image-card">


            <img src="../img/manicurista.jpg"
                 alt="Manicurista Loren Nails"
                 class="hero-img">


        </div>


    </div>


</main>



<!-- =========================================================
     FRANJA DE BENEFICIOS
========================================================= -->

<section class="features-bar-container">


    <div class="features-bar">


        <!-- BENEFICIO 1 -->

        <div class="feature-item">


            <div class="feature-icon-bg">

                💎

            </div>


            <div class="feature-text">

                <strong>

                    Diseños exclusivos

                </strong>


                <span>

                    Tendencias únicas para destacar tu estilo.

                </span>

            </div>


        </div>



        <div class="feature-divider"></div>



        <!-- BENEFICIO 2 -->

        <div class="feature-item">


            <div class="feature-icon-bg">

                💖

            </div>


            <div class="feature-text">

                <strong>

                    Atención personalizada

                </strong>


                <span>

                    Te escuchamos y creamos la experiencia ideal para ti.

                </span>

            </div>


        </div>



        <div class="feature-divider"></div>



        <!-- BENEFICIO 3 -->

        <div class="feature-item">


            <div class="feature-icon-bg">

                🌸

            </div>


            <div class="feature-text">

                <strong>

                    Productos de alta calidad

                </strong>


                <span>

                    Usamos productos premium que cuidan tus uñas.

                </span>

            </div>


        </div>



        <div class="feature-divider"></div>



        <!-- BENEFICIO 4 -->

        <div class="feature-item">


            <div class="feature-icon-bg">

                🕒

            </div>


            <div class="feature-text">

                <strong>

                    Agenda fácil y rápida

                </strong>


                <span>

                    Reserva tu cita en segundos desde cualquier dispositivo.

                </span>

            </div>


        </div>


    </div>

</section>



<!-- =========================================================
     SECCIÓN ¿CÓMO LO HACEMOS?
========================================================= -->

<section class="about">


    <div class="about-details">


        <!-- =================================================
             COLLAGE DE IMÁGENES
        ================================================== -->

        <div class="about-collage">


            <div class="img-placeholder img-tall">

                Foto 1

            </div>


            <div class="img-placeholder img-tall img-offset">

                Foto 2

            </div>


        </div>



        <!-- =================================================
             INFORMACIÓN
        ================================================== -->

        <div class="about-details-text">


            <p class="about-tag">

                Conoce más

            </p>



            <h2 class="about-title">

                ¿Cómo lo hacemos?

            </h2>



            <p class="about-desc">

                Creamos experiencias pensadas para ti:

                espacios modernos, bioseguridad y un equipo

                capacitado que cuida cada detalle de principio a fin.

            </p>



            <!-- CARACTERÍSTICAS -->

            <div class="about-features">


                <!-- CARACTERÍSTICA 1 -->

                <div class="feature-item">


                    <div class="feature-icon">

                        <i>💎</i>

                    </div>


                    <div>

                        <h4 class="feature-title">

                            Diseños exclusivos

                        </h4>


                        <p class="feature-desc">

                            Tendencias únicas para destacar tu estilo.

                        </p>

                    </div>


                </div>



             

                <div class="feature-item">


                    <div class="feature-icon">

                        <i>💖</i>

                    </div>


                    <div>

                        <h4 class="feature-title">

                            Atención personalizada

                        </h4>


                        <p class="feature-desc">

                            Te escuchamos y creamos la experiencia ideal para ti.

                        </p>

                    </div>


                </div>


            </div>


        </div>


    </div>


</section>



</body>

</html>