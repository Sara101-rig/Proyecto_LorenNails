<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar contraseña - Loren Nails</title>
  
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/recuperar-password.css">
</head>
<body>

  <div class="card">
    <div class="icon-circle">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
    </div>

    <p class="titulo">Loren Nails</p>
    <p class="subtitulo">Recupera el acceso a tu cuenta</p>
  
    <form action="${pageContext.request.contextPath}/RecuperarPasswordServlet" method="post">
      <div class="campo">
        <label for="correo">Correo electrónico</label>
        <input type="email" id="correo" name="correo" placeholder="nombre@correo.com" required>
      </div>

      <button type="submit" class="btn-enviar">Enviar enlace de recuperación</button>
    </form>


    <a href="${pageContext.request.contextPath}/vista/login.jsp" class="link-volver">Volver a iniciar sesión</a>
  </div>

</body>
</html>