<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo - Loren Nails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/catalogo.css">
</head>
<body>

    <nav class="navbar">
        <div class="nav-logo">
            <div class="logo-badge">
                <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C12 2 8 6 8 10.5C8 13 9.8 15 12 15C14.2 15 16 13 16 10.5C16 6 12 2 12 2Z" fill="white"/></svg>
            </div>
            <div class="logo-text">LOREN<span>NAILS</span></div>
        </div>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/index.jsp">Inicio</a>
            <a href="${pageContext.request.contextPath}/vista/servicios.jsp">Servicios</a>
            <a href="${pageContext.request.contextPath}/vista/catalogo.jsp" class="active">Catálogo</a>
            <a href="${pageContext.request.contextPath}/vista/conocenos.jsp">Nosotros</a>
            <a href="${pageContext.request.contextPath}/vista/contacto.jsp">Contacto</a>
            
        </div>
        <div class="nav-actions">
            <% 
                String correoUsuario = (String) session.getAttribute("correoUsuario");
                if (correoUsuario != null) {
            %>
                <span class="user-greeting">Hola, <%= correoUsuario %></span>
                <a href="${pageContext.request.contextPath}/LogoutServlet" class="btn-outline">Cerrar sesión</a>
            <% 
                } else { 
            %>
                <a href="${pageContext.request.contextPath}/vista/login.jsp" class="btn-outline">Iniciar sesión</a>
                <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="btn-solid">Agendar cita</a>
            <% 
                } 
            %>
        </div>
    </nav>

    <header class="catalog-header">
        <h1>Nuestro Catálogo de Diseños</h1>
        <p>Explora nuestra colección de diseños únicos creados por nuestras artistas. Filtra por categoría y elige tu favorito.</p>
    </header>

    <div class="search-row">
        <div class="search-box">
            <svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.6"/><path d="M21 21L16.5 16.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
            <input type="text" placeholder="Buscar diseños...">
        </div>
        <select class="sort-select">
            <option>Ordenar por: Defecto</option>
            <option>Precio: menor a mayor</option>
            <option>Precio: mayor a menor</option>
            <option>Más recientes</option>
        </select>
    </div>

    <div class="filter-row">
        <button class="filter-chip active">Todos</button>
        <button class="filter-chip">Manicure</button>
        <button class="filter-chip">Pedicure</button>
        <button class="filter-chip">Semipermanente</button>
        <button class="filter-chip">Acrílicas</button>
        <button class="filter-chip">Nail Art</button>
        <a href="${pageContext.request.contextPath}/vista/cuidados.jsp" class="filter-chip" style="text-decoration: none; display: inline-block;">Cuidados</a>
    </div>

    <p class="results-count">8 diseños encontrados</p>

    <div class="catalog-grid">

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/french.jpg" alt="French Clásico">
                <span class="badge-destacado">★ Destacado</span>
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>French Clásico</h3>
                <div class="card-meta">
                    <span class="tag tag-manicure">Manicure</span>
                    <span class="price">$20.000</span>
                </div>
                <span class="duration">60 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/ojodegato.jpg" alt="Ojo De Gato">
                <span class="badge-destacado">★ Destacado</span>
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Ojo De Gato</h3>
                <div class="card-meta">
                    <span class="tag tag-semi">Semipermanente</span>
                    <span class="price">$47.000</span>
                </div>
                <span class="duration">1 h 20 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/florprimaveral.jpg" alt="Floral Primavera">
                <span class="badge-destacado">★ Destacado</span>
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Floral Primavera</h3>
                <div class="card-meta">
                    <span class="tag tag-nailart">Nail Art</span>
                    <span class="price">$80.000</span>
                </div>
                <span class="duration">1 h 40 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/ombresunset.jpg" alt="Ombre Sunset">
                <span class="badge-destacado">★ Destacado</span>
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Ombre Sunset</h3>
                <div class="card-meta">
                    <span class="tag tag-acrilicas">Acrílicas</span>
                    <span class="price">$90.000</span>
                </div>
                <span class="duration">120 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/pedicura.jpg" alt="Pedicure Spa">
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Pedicure Spa</h3>
                <div class="card-meta">
                    <span class="tag tag-pedicure">Pedicure</span>
                    <span class="price">$55.000</span>
                </div>
                <span class="duration">1 h 30 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/marmoleadonude.jpg" alt="Marmoleado Nude">
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Marmoleado Nude</h3>
                <div class="card-meta">
                    <span class="tag tag-semi">Semipermanente</span>
                    <span class="price">$47.000</span>
                </div>
                <span class="duration">1 h 20 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/cristales3d.jpg" alt="Cristales 3D">
                <span class="badge-destacado">★ Destacado</span>
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Cristales 3D</h3>
                <div class="card-meta">
                    <span class="tag tag-nailart">Nail Art</span>
                    <span class="price">$95.000</span>
                </div>
                <span class="duration">110 min</span>
            </div>
        </div>

        <div class="design-card">
            <div class="card-image">
                <img src="${pageContext.request.contextPath}/img/babyboomer.jpg" alt="Baby Boomer">
                <button class="btn-heart">♡</button>
            </div>
            <div class="card-body">
                <h3>Baby Boomer</h3>
                <div class="card-meta">
                    <span class="tag tag-acrilicas">Acrílicas</span>
                    <span class="price">$90.000</span>
                </div>
                <span class="duration">120 min</span>
            </div>
        </div>

    </div>

    <a href="${pageContext.request.contextPath}/vista/agenda.jsp" class="floating-cta">
        <svg viewBox="0 0 24 24" fill="none"><rect x="3.5" y="5.5" width="17" height="15" rx="3" stroke="white" stroke-width="1.5"/><path d="M3.5 9.5H20.5" stroke="white" stroke-width="1.5"/><path d="M8 3.5V7" stroke="white" stroke-width="1.5" stroke-linecap="round"/><path d="M16 3.5V7" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>
        Agendar cita
    </a>

</body>
</html>