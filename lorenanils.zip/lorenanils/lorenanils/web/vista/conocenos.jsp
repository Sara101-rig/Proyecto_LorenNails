<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conócenos - Loren Nails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/conocenos.css">
</head>
<body>


    <header class="navbar">
        <a href="${pageContext.request.contextPath}/vista/inicio.jsp" class="brand-logo">
            <span class="brand-badge">LN⁺</span>
            <span>LOREN NAILS</span>
        </a>
        <div class="nav-links">
            <a href="${pageContext.request.contextPath}/vista/inicio.jsp">Inicio</a>
            <a href="${pageContext.request.contextPath}/vista/servicios.jsp">Servicios</a>
            <a href="${pageContext.request.contextPath}/vista/catalogo.jsp">Catálogo</a>
            <a href="${pageContext.request.contextPath}/vista/conocenos.jsp" class="active">Nosotros</a>
            <a href="${pageContext.request.contextPath}/vista/contacto.jsp">Contacto</a>
        </div>
    </header>

    <main class="about-container">
        
       
        <section class="about-hero">
            <span class="sub-heading">NUESTRA HISTORIA Y PASIÓN ✨</span>
            <h1>Pasión por el detalle y el cuidado de tus manos</h1>
            <p>
                En <strong>Loren Nails</strong> creemos que tus manos expresan tu personalidad y estilo único. 
                Nos dedicamos a brindar un servicio de alta calidad enfocado en la belleza, la bioseguridad y la salud ungular.
            </p>
        </section>

      
        <section class="pillars-grid">
            <div class="pillar-card">
                <div class="pillar-icon">🌸</div>
                <h3>Técnicas Especializadas</h3>
                <p>Manejamos desde manicura convencional y semipermanente hasta sistemas avanzados como Acrílico, Polygel, Base Rubber, Dipping y Soft Gel.</p>
            </div>

            <div class="pillar-card">
                <div class="pillar-icon">💎</div>
                <h3>Calidad & Durabilidad</h3>
                <p>Trabajamos con insumos de alta gama para asegurar acabados impecables, resistentes y alineados a las tendencias actuales.</p>
            </div>

            <div class="pillar-card">
                <div class="pillar-icon">🛡️</div>
                <h3>Bioseguridad Garantizada</h3>
                <p>Tu salud es nuestra prioridad. Cumplimos con estrictos protocolos de esterilización e higienización de herramientas en cada sesión.</p>
            </div>
        </section>
       
        <section class="mission-vision-section">
            <div class="mv-card">
                <h2>Nuestra Misión</h2>
                <p>Ofrecer una experiencia relajante y personalizada de estética y cuidado de uñas, utilizando productos de alta calidad y técnicas innovadoras para realzar la confianza y elegancia de cada cliente.</p>
            </div>

            <div class="mv-card accent-card">
                <h2>Nuestra Visión</h2>
                <p>Consolidarnos como el estudio de belleza ungular de referencia, reconocido por la excelencia técnica, la innovación constante en nuestros sistemas y la atención cálida y oportuna.</p>
            </div>
        </section>

        
        <section class="cta-banner">
            <h2>¿Lista para consentir tus manos?</h2>
            <p>Agenda tu cita con nuestras manicuristas expertas y vive la experiencia Loren Nails.</p>
            <div class="cta-buttons">
                <a href="agenda.jsp" class="btn-primary-cta">Reserva tu Cita</a>
                <a href="servicios.jsp" class="btn-secondary-cta">Ver Servicios</a>
            </div>
        </section>

    </main>

</body>
</html>