<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis citas - Loren Nails</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tabler-icons/2.44.0/iconfont/tabler-icons.min.css">

<link rel="stylesheet" href="<%= request.getContextPath() %>/css/citas.css">
</head>
<body>

  <div class="contenedor">

    <div class="encabezado">
      <p class="titulo">Mis citas</p>
      <p class="subtitulo">Consulta y gestiona tus reservas en Loren Nails</p>
    </div>

    <div class="pestanas">
      <div class="pestana activa">Próximas</div>
      <div class="pestana">Anteriores</div>
      <div class="pestana">Canceladas</div>
    </div>

    <div class="grid-citas">

      <div class="tarjeta borde-rosa">
        <div class="tarjeta-header">
          <p class="servicio">Nail art</p>
          <span class="badge badge-confirmada">Confirmada</span>
        </div>
        <p class="dato"><i class="ti ti-calendar"></i>12 jun 2025</p>
        <p class="dato dato-espacio"><i class="ti ti-clock"></i>02:00 pm · 60 min</p>
        <div class="acciones">
          <button class="btn btn-neutro">Reprogramar</button>
          <button class="btn btn-cancelar">Cancelar</button>
        </div>
      </div>

      <div class="tarjeta borde-ambar">
        <div class="tarjeta-header">
          <p class="servicio">Acrílicas</p>
          <span class="badge badge-pendiente">Pendiente</span>
        </div>
        <p class="dato"><i class="ti ti-calendar"></i>20 jun 2025</p>
        <p class="dato dato-espacio"><i class="ti ti-clock"></i>10:00 am · 120 min</p>
        <div class="acciones">
          <button class="btn btn-neutro">Reprogramar</button>
          <button class="btn btn-cancelar">Cancelar</button>
        </div>
      </div>

      <a href="agenda.jsp" class="tarjeta tarjeta-nueva" style="text-decoration: none; color: inherit;">
    <i class="ti ti-plus"></i>
    <p>Agendar nueva cita</p>
</a>

    </div>

  </div>

</body>
</html>