<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - Loren Nails</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/login.css">
</head>
<body>

    <div class="main-container">

        <div class="left-banner">
            <div class="brand-logo">
                <div class="brand-badge">LN⁺</div>
                <span>LOREN NAILS</span>
            </div>
            
            <div class="banner-content">
                <div class="banner-subtitle">BIENVENIDA A TU ESPACIO ♥</div>
                <h1>Cuidado y estilo <i>excepcional</i> para tus manos.</h1>
                <p class="banner-description">Regístrate para agendar tus citas fácilmente, llevar el control de tus servicios y disfrutar de una experiencia única de belleza.</p>
                
                <div class="feature-list">
                    <div class="feature-item">
                        <div class="feature-icon">💎</div>
                        <span>Diseños personalizados y profesionales</span>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">📅</div>
                        <span>Gestión rápida de tus citas favoritas</span>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">⭐</div>
                        <span>Experiencia premium desde el primer clic</span>
                    </div>
                </div>
            </div>

            <div class="footer-copy">© 2026 Loren Nails System ✨</div>
        </div>

        <div class="right-form">
            <div class="form-wrapper">
                <h2>Crea tu cuenta</h2>
                <p>Ingresa tus datos personales para registrarte.</p>
                
                <form action="${pageContext.request.contextPath}/RegistroServlet" method="POST">
                    
                    <div class="form-group">
                        <label>Nombre</label>
                        <div class="input-container">
                            <span>👤</span>
                            <input type="text" name="nombre" placeholder="Tu nombre" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Apellido</label>
                        <div class="input-container">
                            <span>👤</span>
                            <input type="text" name="apellido" placeholder="Tu apellido" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Tipo de Documento</label>
                        <div class="input-container">
                            <span>🪪</span>
                            <select name="tipo_documento" required>
                                <option value="" disabled selected>Selecciona un tipo</option>
                                <option value="1">Cédula de ciudadanía</option>
                                <option value="2">Tarjeta de identidad</option>
                                <option value="3">Cédula de extranjería</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Número de Identidad</label>
                        <div class="input-container">
                            <span>🔢</span>
                            <input type="text" name="documento" placeholder="Número de documento" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Fecha de Nacimiento</label>
                        <div class="input-container">
                            <span>📅</span>
                            <input type="date" name="fechaNacimiento" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Teléfono</label>
                        <div class="input-container">
                            <span>📞</span>
                            <input type="text" name="telefono" placeholder="Número de teléfono" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Correo Electrónico</label>
                        <div class="input-container">
                            <span>✉️</span>
                            <input type="email" name="correo" placeholder="correo@ejemplo.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Dirección</label>
                        <div class="input-container">
                            <span>📍</span>
                            <input type="text" name="direccion" placeholder="Dirección" required>
                        </div>
                    </div>

                    <!-- Caja de seguridad -->
                    <div class="security-box">
                        <div class="security-box-icon">🔒</div>
                        <div class="security-box-text">
                            <h4>Tu información está protegida</h4>
                            <p>Nos tomamos muy en serio la seguridad de tus datos.</p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Contraseña</label>
                        <div class="input-container">
                            <span>🔒</span>
                            <input type="password" name="contrasena" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit">
                        Crear mi cuenta <span>→</span>
                    </button>
                </form>

                <div class="register-text">
                    ¿Ya tienes una cuenta? <a href="${pageContext.request.contextPath}/vista/login.jsp">Inicia sesión</a>
                </div>
            </div>
        </div>
    </div>

</body>
</html>