<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - Loren Nails</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/login.css">
</head>
<body>

    <div class="main-container">

      
        <div class="left-banner">
            <div class="brand-logo">
                <div class="brand-badge">LN⁺</div>
                <span>LOREN NAILS</span>
            </div>
            
            <div class="banner-content">
                <div class="banner-subtitle">¡QUÉ GUSTO VERTE DE NUEVO! ♥</div>
                <h1>Tu estilo, tu cita, <i>tu momento</i>.</h1>
                <p class="banner-description">Inicia sesión para gestionar tus reservas activas, consultar tu historial de servicios y descubrir nuevos diseños exclusivos.</p>
                
                <div class="feature-list">
                    <div class="feature-item">
                        <div class="feature-icon">💅</div>
                        <span>Revisa tus citas agendadas</span>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">✨</div>
                        <span>Accede a promociones exclusivas</span>
                    </div>
                    <div class="feature-item">
                        <div class="feature-icon">🌸</div>
                        <span>Atención personalizada garantizada</span>
                    </div>
                </div>
            </div>

            <div class="footer-copy">© 2026 Loren Nails System ✨</div>
        </div>

        
        <div class="right-form">
            <div class="form-wrapper">
                <h2>Bienvenida de nuevo</h2>
                <p>Ingresa tus credenciales para acceder a tu cuenta.</p>
                
              
                <%
                    String mensaje = request.getParameter("mensaje");
                    String error = request.getParameter("error");
                    
                    if (mensaje != null && mensaje.equals("enviado")) {
                %>
                    <div class="alert alert-success">
                        ✅ ¡Listo! Si el correo está registrado, hemos procesado la solicitud de recuperación.
                    </div>
                <%
                    } else if (error != null && error.equals("noencontrado")) {
                %>
                    <div class="alert alert-error">
                        ❌ El correo electrónico ingresado no se encuentra registrado en el sistema.
                    </div>
                <%
                    }
                %>
                
                <form action="${pageContext.request.contextPath}/LoginServlet" method="POST">
                    
                    <div class="form-group">
                        <label>Correo Electrónico</label>
                        <div class="input-container">
                            <span>✉️</span>
                            <input type="email" name="correo" placeholder="correo@ejemplo.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Contraseña</label>
                        <div class="input-container">
                            <span>🔒</span>
                            <input type="password" name="contrasena" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="recordarme"> Recordarme
                        </label>
                        <a href="${pageContext.request.contextPath}/vista/recuperar.jsp" class="forgot-password">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn-submit">
                        Iniciar Sesión <span>→</span>
                    </button>
                </form>

                <div class="register-text">
                    ¿Aún no tienes una cuenta? <a href="${pageContext.request.contextPath}/vista/registro.jsp">Regístrate aquí</a>
                </div>
            </div>
        </div>

    </div>

</body>
</html> 