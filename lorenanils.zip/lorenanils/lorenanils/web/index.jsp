<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    response.sendRedirect("vista/inicio.jsp");
%>