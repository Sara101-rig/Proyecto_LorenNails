<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loren Nails - Registro</title>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..600;1,9..144,300..600&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/registro.css">
</head>
<body>

    <div class="main-container">
        

        <div class="left-banner">
            <div>
                <div class="brand-logo">
                    <div class="brand-badge">LN</div>
                    <span>LOREN NAILS</span>
                </div>

                <div class="banner-content">
                    <p class="banner-subtitle">BIENVENIDA A TU ESPACIO</p>
                    <h1>Cuidado y estilo <i>excepcional</i> para tus manos.</h1>
                    <p class="banner-description">
                        Regístrate para agendar tus citas fácilmente, llevar el control de tus servicios y disfrutar de una experiencia única de belleza.
                    </p>
                </div>
            </div>

           
            <div class="feature-list">
                <div class="feature-item">
                    <div class="feature-icon">✨</div>
                    <span>Diseños personalizados y profesionales</span>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">📅</div>
                    <span>Gestión rápida de tus citas favoritas</span>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">⭐</div>
                    <span>Experiencia premium desde el primer clic</span>
                </div>
            </div>
        </div>

      
        <div class="right-form">
            <div class="form-wrapper">
                <h2>Crea tu cuenta</h2>
                <p class="form-subtitle">Ingresa tus datos personales para registrarte.</p>

                <form action="RegistroServlet" method="POST">
                    
                    <div class="form-grid-2">
                        
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="apellido">Apellido</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                <input type="text" id="apellido" name="apellido" placeholder="Tu apellido" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-grid-2">
                        
                        <div class="form-group">
                            <label for="tipo_doc">Tipo de Documento</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"></rect><line x1="6" y1="9" x2="10" y2="9"></line><line x1="6" y1="13" x2="14" y2="13"></line></svg>
                                <select id="tipo_doc" name="tipo_doc" required>
                                    <option value="" disabled selected>Selecciona</option>
                                    <option value="CC">Cédula de Ciudadanía</option>
                                    <option value="TI">Tarjeta de Identidad</option>
                                    <option value="CE">Cédula de Extranjería</option>
                                </select>
                            </div>
                        </div>

                        <!-- Número de Identidad -->
                        <div class="form-group">
                            <label for="documento">Número de Identidad</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V4h16v3M9 20h6M12 4v16"></path></svg>
                                <input type="text" id="documento" name="documento" placeholder="Nro de documento" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-grid-2">
                        <!-- Teléfono -->
                        <div class="form-group">
                            <label for="telefono">Teléfono</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                <input type="tel" id="telefono" name="telefono" placeholder="Número de teléfono" required>
                            </div>
                        </div>

                        <!-- Fecha de Nacimiento -->
                        <div class="form-group">
                            <label for="f_nacimiento">Fecha de Nacimiento</label>
                            <div class="input-container">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                <input type="date" id="f_nacimiento" name="f_nacimiento" required>
                            </div>
                        </div>
                    </div>

                    <!-- Correo Electrónico (Ancho Completo) -->
                    <div class="form-group">
                        <label for="correo">Correo Electrónico</label>
                        <div class="input-container">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            <input type="email" id="correo" name="correo" placeholder="correo@ejemplo.com" required>
                        </div>
                    </div>

                    <!-- Contraseña (Ancho Completo) -->
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="input-container">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                            <input type="password" id="password" name="password" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit">
                        Crear Cuenta &rarr;
                    </button>

                    <p class="register-text">
                        ¿Ya tienes una cuenta? <a href="login.jsp">Inicia sesión aquí</a>
                    </p>

                </form>
            </div>
        </div>

    </div>

</body>
</html