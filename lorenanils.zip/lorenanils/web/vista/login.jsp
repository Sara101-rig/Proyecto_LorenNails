<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loren Nails - Iniciar Sesión</title>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..600;1,9..144,300..600&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/login.css?v=2.0">
</head>
<body>

    <div class="main-container">
        
  
        <div class="left-banner">
            <div>
                
                <div class="brand-logo">
                    <div class="brand-badge">LN</div>
                    <span>LOREN NAILS</span>
                </div>

        
                <div class="banner-content">
                    <p class="banner-subtitle">¡Qué gusto verte de nuevo!</p>
                    <h1>Tu estilo, tu cita, <i>tu momento.</i></h1>
                    <p class="banner-description">
                        Inicia sesión para gestionar tus reservas activas, consultar tu historial de servicios y descubrir nuevos diseños exclusivos.
                    </p>
                </div>
            </div>

           
            <div class="feature-list">
                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                    </div>
                    <span>Revisa tus citas agendadas</span>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
                    </div>
                    <span>Accede a promociones exclusivas</span>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                    </div>
                    <span>Atención personalizada garantizada</span>
                </div>

                <p class="footer-copy">&copy; 2026 Loren Nails System</p>
            </div>
        </div>

        <!-- COLUMNA DERECHA: FORMULARIO -->
        <div class="right-form">
            <div class="form-wrapper">
                <h2>Bienvenida de nuevo</h2>
                <p class="form-subtitle">Ingresa tus credenciales para acceder a tu cuenta.</p>

                <form action="<%= request.getContextPath() %>/LoginServlet" method="POST">
                    
                    <div class="form-group">
                        <label for="correo">Correo Electrónico</label>
                        <div class="input-container">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            <input type="email" id="correo" name="correo" placeholder="correo@ejemplo.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="input-container">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#B8A5AA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                            <input type="password" id="password" name="password" placeholder="••••••••" required>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember"> Recordarme
                        </label>
                        <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
                    </div>

                    <button type="submit" class="btn-submit">
                        Iniciar Sesión &rarr;
                    </button>

                    <p class="register-text">
                        ¿Aún no tienes una cuenta? <a href="registro.jsp">Regístrate aquí</a>
                    </p>

                </form>
            </div>
        </div>

    </div>

</body>
</html>