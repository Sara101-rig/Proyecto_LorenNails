<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loren Nails - Inicio</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,500;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Dancing+Script:wght@600;700&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,500&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<%= request.getContextPath() %>/css/inicio.css">
</head>

<body>

<header class="navbar">
    <div class="nav-group">
        <a href="inicio.jsp" class="nav-link active">
            Inicio
            <span class="active-dot">✦</span>
        </a>
    </div>

    <a href="inicio.jsp" class="brand-logo">
        <img src="../img/logo.png" alt="Loren Nails Logo" class="logo-img">
    </a>

    <div class="nav-group">
        <a href="conocenos.jsp" class="nav-link">
            Conócenos
        </a>

        <a href="login.jsp" class="btn-login">
            <span class="user-icon">👤</span>
            Iniciar sesión
        </a>
    </div>
</header>

<main class="hero-container">
    <div class="hero-content">
        <span class="tagline">
            💅🏻 LOREN NAILS SYSTEM ✨
        </span>

        <h1 class="hero-title">
            <span class="title-main">
                Tu momento
            </span>
            <br>
            <span class="title-cursive">
                para brillar
                <span class="sparkle">
                    ✨
                </span>
            </span>
            <br>
            <span class="title-main">
                comienza aquí
            </span>
        </h1>

        <p class="hero-description">
            Agenda tu cita, elige tu estilo y disfruta una experiencia
            <strong>
                pensada para ti.
            </strong>
            ✨
        </p>

        <div class="hero-buttons">
            <a href="catalogo.jsp" class="btn-primary">
                <span class="btn-icon">
                    ✨
                </span>
                Catálogo
                <span class="btn-arrow">
                    →
                </span>
            </a>

            <a href="agenda.jsp" class="btn-secondary">
                <span class="btn-icon">
                    📅
                </span>
                Agenda tu cita
            </a>
        </div>
    </div>

    <div class="hero-image-wrapper">
        <div class="image-card">
            <img src="../img/manicurista.jpg" alt="Manicurista Loren Nails" class="hero-img">
        </div>
    </div>
</main>


<section class="about">
    <div class="about-details">
        <div class="about-collage">
            <div class="img-placeholder img-tall">
                Foto 1
            </div>
            <div class="img-placeholder img-tall img-offset">
                Foto 2
            </div>
        </div>

        <div class="about-details-text">
            <p class="about-tag">
                Conoce más
            </p>

            <h2 class="about-title">
                ¿Cómo lo hacemos?
            </h2>

            <p class="about-desc">
                Creamos experiencias pensadas para ti:
                espacios modernos, bioseguridad y un equipo
                capacitado que cuida cada detalle de principio a fin.
            </p>

            <div class="about-features">
                <div class="feature-item">
                    <div class="feature-icon">
                        <i>💎</i>
                    </div>
                    <div>
                        <h4 class="feature-title">
                            Diseños exclusivos
                        </h4>
                        <p class="feature-desc">
                            Tendencias únicas para destacar tu estilo.
                        </p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i>💖</i>
                    </div>
                    <div>
                        <h4 class="feature-title">
                            Atención personalizada
                        </h4>
                        <p class="feature-desc">
                            Te escuchamos y creamos la experiencia ideal para ti.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="features-bar-container">
    <div class="features-bar">
        <div class="feature-item">
            <div class="feature-icon-bg">
                💎
            </div>
            <div class="feature-text">
                <strong>
                    Diseños exclusivos
                </strong>
                <span>
                    Tendencias únicas para destacar tu estilo.
                </span>
            </div>
        </div>

        <div class="feature-divider"></div>

        <div class="feature-item">
            <div class="feature-icon-bg">
                💖
            </div>
            <div class="feature-text">
                <strong>
                    Atención personalizada
                </strong>
                <span>
                    Te escuchamos y creamos la experiencia ideal para ti.
                </span>
            </div>
        </div>

        <div class="feature-divider"></div>

        <div class="feature-item">
            <div class="feature-icon-bg">
                🌸
            </div>
            <div class="feature-text">
                <strong>
                    Productos de alta calidad
                </strong>
                <span>
                    Usamos productos premium que cuidan tus uñas.
                </span>
            </div>
        </div>

        <div class="feature-divider"></div>

        <div class="feature-item">
            <div class="feature-icon-bg">
                🕒
            </div>
            <div class="feature-text">
                <strong>
                    Agenda fácil y rápida
                </strong>
                <span>
                    Reserva tu cita en segundos desde cualquier dispositivo.
                </span>
            </div>
        </div>
    </div>
</section>

<footer class="site-footer">
    <div class="footer-container">
        
       
        <div class="footer-col brand-col">
            <div class="footer-logo">
                <div class="footer-badge">LN</div>
                <span>LOREN<span>NAILS</span></span>
            </div>
            <p class="footer-desc">
                Tu espacio de confianza para el cuidado y diseño de uñas. Tu estilo, tu cita, tu momento.
            </p>
        </div>

       
        <div class="footer-col">
            <h4>Explora</h4>
            <ul>
                <li><a href="${pageContext.request.contextPath}/inicio.jsp">Inicio</a></li>
                <li><a href="${pageContext.request.contextPath}/vista/servicios.jsp">Servicios</a></li>
                <li><a href="${pageContext.request.contextPath}/vista/catalogo.jsp">Catálogo</a></li>
                <li><a href="${pageContext.request.contextPath}/vista/agenda.jsp">Agendar cita</a></li>
            </ul>
        </div>

     
        <div class="footer-col social-col">
            <h4>Síguenos</h4>
            <p>Encuéntranos en nuestras redes para ver más diseños.</p>
            <div class="social-icons">
                <!-- Instagram -->
                <a href="https://instagram.com" target="_blank" class="social-icon" aria-label="Instagram">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                </a>
               
                <a href="https://tiktok.com" target="_blank" class="social-icon" aria-label="TikTok">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"></path></svg>
                </a>
                <!-- WhatsApp -->
                <a href="https://whatsapp.com" target="_blank" class="social-icon" aria-label="WhatsApp">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                </a>
            </div>
        </div>

    </div>


    <div class="footer-bottom">
        <p>&copy; 2026 Loren Nails System. Todos los derechos reservados.</p>
    </div>
</footer>

</body>
</html>