package Servlet;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String correo = request.getParameter("correo");
        String contrasena = request.getParameter("password");

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        boolean accesoValido = usuarioDAO.validarLogin(correo, contrasena);

        if (accesoValido) {
            HttpSession session = request.getSession();
            
            session.setAttribute("correoUsuario", correo);
            
            // Obtenemos el objeto usuario completo desde la BD
            Usuario usuarioObj = usuarioDAO.obtenerUsuarioPorCorreo(correo); 
            if (usuarioObj != null) {
                session.setAttribute("nombreUsuario", usuarioObj.getNombre()); 
            }
            
            // Redirigimos al catálogo usando la carpeta en singular "vista"
            response.sendRedirect(request.getContextPath() + "/vista/catalogo.jsp");
            
        } else {
            // Si falla, redirige al login con parámetro de error
            response.sendRedirect(request.getContextPath() + "/vista/login.jsp?error=1");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        response.sendRedirect(request.getContextPath() + "/vista/login.jsp");
    }
}